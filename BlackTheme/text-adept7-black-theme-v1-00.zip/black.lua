-- Copyright 2013 R. Pusztai rjpcomputing<att>gmail.com. MIT LICENSE.
-- Black (based on Dark) theme for Textadept.

local buffer = buffer
local c = _SCINTILLA.constants
local property, property_int = buffer.property, buffer.property_int

-- Colors
property['color.green']	       = 0x4D994D
property['color.br_green']     = 0x00FF00
property['color.blue']         = 0xC08040
property['color.red']          = 0x0000FF
property['color.yellow']       = 0x4D9999
property['color.teal']         = 0x99994D
property['color.white']        = 0xC0C0C0
property['color.black']        = 0x000000
property['color.grey']         = 0x808080
property['color.purple']       = 0x994D99
property['color.orange']       = 0x0080FF
property['color.pink']         = 0xFF00FF
property['color.burgandy']     = 0x404080
property['color.brown']        = 0x004080
property['color.keyword']      = 0xFF8000
property['color.margin']       = 0x202020
property['color.light_black']  = 0x333333
property['color.light_grey']   = 0x999999
property['color.light_pink']   = 0x9966FF
property['color.dark_grey']    = 0x444444
property['color.pure_white']   = 0xFFFFFF

-- Styles ---------------------------------------------------------------------
--

-- Default font.
property['font']         = 'Bitstream Vera Sans Mono'
property['fontsize']     = 10
if WIN32 then
	property['font']     = 'Courier New'
elseif OSX then
	property['font']     = 'Monaco'
	property['fontsize'] = 12
end

-- Token styles.
property['style.nothing']      = ''
property['style.char']         = 'fore:%(color.red),bold'
property['style.class']        = 'fore:%(color.white),underline'
property['style.comment']      = 'fore:%(color.br_green)'
property['style.constant']     = 'fore:%(color.teal),bold'
property['style.definition']   = 'fore:%(color.red),bold'
property['style.error']        = 'fore:%(color.red),italics'
property['style.function']     = 'fore:%(color.white),bold'
property['style.keyword']      = 'fore:%(color.keyword)'
property['style.label']        = 'fore:%(color.orange)'
property['style.number']       = 'fore:%(color.pink)'
property['style.operator']     = 'fore:%(color.grey)'
property['style.regex']        = 'fore:%(color.light_green)'
property['style.string']       = 'fore:%(color.orange)'
property['style.preprocessor'] = 'fore:%(color.burgandy)'
property['style.tag']          = 'fore:%(color.teal),bold'
property['style.type']         = 'fore:%(color.keyword)'
property['style.variable']     = 'fore:%(color.brown),italics'
property['style.whitespace']   = ''
property['style.embedded']     = '%(style.tag),back:%(color.light_black)'
property['style.identifier']   = '%(style.nothing)'

-- Predefined styles.
property['style.default']      = 'font:%(font),size:%(fontsize),'..
                                 'fore:%(color.white),back:%(color.black)'
property['style.linenumber']   = 'fore:%(color.teal),back:%(color.black)'
property['style.bracelight']   = 'fore:%(color.light_pink),bold'
property['style.bracebad']     = 'fore:%(color.red),bold'
property['style.controlchar']  = '%(style.nothing)'
property['style.indentguide']  = 'fore:%(color.grey),back:$(color.black)'
property['style.calltip']      = 'fore:%(color.white),back:%(color.dark_grey)'

-- Buffer Control -------------------------------------------------------------
--

-- Multiple Selection and Virtual Space
buffer.multiple_selection = true
buffer.additional_selection_typing = true
--buffer.additional_sel_alpha =
--buffer.additional_sel_fore =
--buffer.additional_sel_back =
--buffer.additional_caret_fore =
--buffer.additional_carets_blink = false
--buffer.additional_carets_visible = false

-- Caret and Selection Styles.
buffer:set_sel_fore(true, property_int['color.light_black'])
buffer:set_sel_back(true, property_int['color.light_grey'])
--buffer.sel_alpha =
buffer.sel_eol_filled = true
buffer.caret_fore = property_int['color.pure_white']
buffer.caret_line_back = property_int['color.dark_grey']
--buffer.caret_line_back_alpha =
--buffer.caret_period = 0
--buffer.caret_style = 2
--buffer.caret_width =
--buffer.caret_sticky = 1

-- Fold Margin.
buffer.margin_type_n[2] = c.MARGIN_SYMBOL
buffer.margin_width_n[0] = 4 + 4 * buffer:text_width(c.STYLE_LINENUMBER, '9') -- Line Number Margin.
buffer.margin_width_n[1] = 0 -- marker margin invisible
buffer.margin_width_n[2] = 10
buffer.margin_mask_n[2] = c.MASK_FOLDERS
buffer.margin_sensitive_n[2] = true
buffer:set_fold_margin_colour(true, property_int['color.margin'])
buffer:set_fold_margin_hi_colour(true, property_int['color.margin'])

-- Fold Margin Markers.
buffer:marker_define(c.MARKNUM_FOLDEROPEN, c.MARK_ARROWDOWN)

buffer.marker_fore[c.MARKNUM_FOLDEROPEN] = property_int['color.light_black']
buffer.marker_back[c.MARKNUM_FOLDEROPEN] = property_int['color.dark_grey']

buffer:marker_define(c.MARKNUM_FOLDER, c.MARK_ARROW)

buffer.marker_fore[c.MARKNUM_FOLDER] = property_int['color.light_black']
buffer.marker_back[c.MARKNUM_FOLDER] = property_int['color.dark_grey']

buffer:marker_define(c.MARKNUM_FOLDERSUB, c.MARK_EMPTY)
buffer:marker_define(c.MARKNUM_FOLDERTAIL, c.MARK_EMPTY)
buffer:marker_define(c.MARKNUM_FOLDEREND, c.MARK_EMPTY)
buffer:marker_define(c.MARKNUM_FOLDEROPENMID, c.MARK_EMPTY)
buffer:marker_define(c.MARKNUM_FOLDERMIDTAIL, c.MARK_EMPTY)

-- Long Lines.
buffer.edge_colour = property_int['color.light_grey']
