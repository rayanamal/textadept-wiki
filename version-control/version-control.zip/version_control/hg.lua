-- Copyright 2012-2013 Mitchell mitchell.att.foicica.com. See LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- Mercurial for the version control module.
module('_M.version_control.hg')]]

-- Markdown:
-- # Settings
--
-- * `HG_CMD` [string]: The Mercurial executable for your platform.
-- * `HG_IGNORE` [string]: The name of Mercurial's hgignore file for ignoring
--   repository files.

M.HG_CMD = 'hg'
M.HG_IGNORE = '.hgignore'

-- Localizations.
local _L = _L
if _L['[hg Commit Buffer]']:find('^No Localization') then
  _L['Warning'] = 'Warning'
  _L['File modified; annotations may be inaccurate'] =
    'File modified; annotations may be inaccurate'
  _L['Branches'] = 'Branches'
  _L['Branch'] = 'Branch'
  _L['File Status'] = 'File Status'
  _L['Status'] = 'Status'
  _L['[hg Commit Buffer]'] = '[hg Commit Buffer]'
  _L['Commit?'] = 'Commit?'
  _L['Proceed with commit?'] = 'Proceed with commit?'
  _L['hg log'] = 'hg log'
  _L['Changeset'] = 'Changeset'
  _L['hg summary'] = 'hg summary'
end

local vcs = _M.version_control
local get_vcs, HG, popen_vcs, q = vcs.get_vcs, vcs.HG, vcs.popen_vcs, vcs.q
local events, events_connect = events, events.connect

-- Map of regexp or shell-style glob characters to Lua pattern characters.
-- @class table
-- @name lua_patt
local lua_patt = {
  -- Regexp and shell-style glob characters.
  ['\\'] = '%',
  -- Shell-style glob characters.
  ['.'] = '%.', ['*'] = '.*', ['?'] = '.', ['/'] = '[/\\]'
}

---
-- Generates a snapopen filter based on the project's ".hgignore" file.
-- There are some crude transforms from regexp and shell-style globs to Lua
-- patterns, so complicated match strings probably will not work.
-- @param root The path of the project's root directory.
-- @see io.snapopen
-- @return filter table
function M._FILTER(root)
  local f = io.open(root..'/'..M.HG_IGNORE)
  if not f then return nil end
  local filter = {extensions = {}, folders = {}}
  local syntax = 'regexp'
  for line in f:lines() do
    if line:find('^%s*syntax:') then
      syntax = line:match('^%s*syntax:%s*(%S+)')
    elseif line ~= '' and not line:find('^#') then
      if syntax == 'regexp' then
        local ext = line:match('^%s*\\%.([%w-]+)$')
        if ext then
          filter.extensions[#filter.extensions + 1] = ext
        else
          -- Crudely convert regexp to Lua pattern.
          filter[#filter + 1] = line:gsub('\\', lua_patt)
        end
      elseif syntax == 'glob' then
        local ext = line:match('^%s*%*%.([%w-]+)$')
        if ext then
          filter.extensions[#filter.extensions + 1] = ext
        else
          -- Crudely convert glob to Lua pattern.
          line = line:gsub('[.\\*?/]', lua_patt)
          if line:find('%b{}') then
            -- Brace expansion, but only one level and set is supported.
            local prefix, options, suffix = line:match('^(.-)(%b{})(.*)$')
            for option in options:sub(2, -2):gmatch('[^,]+') do
              filter[#filter + 1]= prefix..option..suffix
            end
          else
            filter[#filter + 1] = line
          end
        end
      end
    end
  end
  f:close()
  return filter
end

---
-- Adds the current file on the next commit.
-- @return `true` on success, `false` otherwise
-- @name add
function M.add()
  local vcs, root = get_vcs()
  if not root or vcs ~= HG or not buffer.filename then return end
  local p = popen_vcs(M.HG_CMD, 'add', {repository = root},
                      q(buffer.filename:iconv(_CHARSET, 'UTF-8')), '2>&1')
  local out = p:read('*all')
  p:close()
  if out ~= '' then ui.print(out) end -- hg error message
  return out == ''
end

local old_margin0_width, annotations = nil, false
---
-- Shows changeset information by line for the current file.
-- The line number margin is changed to show the user and revision id
-- responsible for each line.
-- Pressing `Esc` or calling `annotate()` again hides annotations.
-- @name annotate
function M.annotate()
  if annotations then restore_margin0() return end
  local vcs, root = get_vcs()
  if not root or vcs ~= HG or not buffer.filename then return end
  local filename = buffer.filename:iconv(_CHARSET, 'UTF-8')
  local basename = filename:sub(#root + 2)
  -- Notify user if the annotation may be inaccurate.
  local p = popen_vcs(M.HG_CMD, 'status',
                      {repository = root, modified = true,
                       ['no-status'] = true})
  for file in p:lines() do
    if file == basename then
      ui.dialogs.msgbox{
        title = _L['Warning'],
        informative_text = _L['File modified; annotations may be inaccurate'],
        icon = 'gtk-dialog-warning'
      }
      break
    end
  end
  p:close()
  -- Read the annotations.
  local revs, max_length = {}, 0
  p = popen_vcs(M.HG_CMD, 'annotate',
                {repository = root, user = true, number = true}, q(filename))
  for line in p:lines() do
    local annotation = line:match('^[^:]+')
    revs[#revs + 1] = annotation
    if #annotation > max_length then max_length = #annotation end
  end
  p:close()
  -- Show the annotations in margin 0.
  old_margin0_width = buffer.margin_width_n[0]
  local c = _SCINTILLA.constants
  buffer.margin_type_n[0] = c.MARGIN_RTEXT
  buffer.margin_width_n[0] = 4 + max_length *
                             buffer:text_width(c.STYLE_LINENUMBER, '9')
  for i = 0, #revs - 1 do
    buffer.margin_text[i] = revs[i + 1]
    buffer.margin_style[i] = c.STYLE_LINENUMBER
  end
  annotations = true
end
-- Restores the default line margin.
local function restore_margin0()
  buffer.margin_type_n[0] = _SCINTILLA.constants.MARGIN_NUMBER
  buffer.margin_width_n[0] = old_margin0_width
  annotations = false
end
events_connect(events.KEYPRESS, function(code)
  if annotations and keys.KEYSYMS[code] == 'esc' then restore_margin0() end
end)
events_connect(events.BUFFER_BEFORE_SWITCH,
               function() if annotations then restore_margin0() end end)

---
-- Sets the current branch name.
-- @param name The name of the branch.
-- @name branch
function M.branch(name)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG or not name then return end
  local p = popen_vcs(M.HG_CMD, 'branch', {repository = root}, q(name))
  ui.print(p:read('*all'))
  p:close()
end

---
-- Lists the repository's named branches in a filteredlist.
-- Depending on a given parameter, the selected branch's revision history is
-- shown or the branch is switched to.
-- @param switch Flag indicating whether or not to switch to the selected
--   branch. Defaults to `false`.
-- @name branches
function M.branches(switch)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  local branches = {}
  local p = popen_vcs(M.HG_CMD, 'branches', {repository = root})
  for line in p:lines() do branches[#branches + 1] = line end
  p:close()
  local branch = ui.filteredlist(_L['Branches'], _L['Branch'], branches)
  if not branch then return end
  branch = branch:match('^(.-)%s+%d+:')
  if not switch then M.log(true, branch) else M.update(branch) end
end

local status = {M = 'changed', A = 'added', R = 'removed', D = 'deleted'}
---
-- Commits the specified files or all outstanding changes.
-- A buffer is opened for the commit message. All the files to commit are
-- listed and can be removed. Calling `commit()` again commits the changeset.
-- @return `true` on success, `false` otherwise
-- @name commit
function M.commit()
  local vcs, root = get_vcs(buffer._vcs_root)
  if not root or vcs ~= HG then return end
  if buffer._type ~= _L['[hg Commit Buffer]'] then
    -- Prepare the commit message buffer.
    -- Change 'M foo' to 'changed foo', 'A bar' to 'added bar', etc.
    local files = {}
    local p = popen_vcs(M.HG_CMD, 'status',
                        {repository = root, modified = true, added = true,
                         removed = true, deleted = true})
    for file in p:lines() do files[#files + 1] = file:gsub('^%a', status) end
    p:close()
    -- Get the username for the commit.
    p = popen_vcs(M.HG_CMD, 'showconfig', {repository = root})
    local user = p:read('*all'):match('ui%.username=([^\r\n]+)')
    p:close()
    -- Get the branch name for the commit.
    p = popen_vcs(M.HG_CMD, 'branch', {repository = root})
    local branch = p:read('*l')
    p:close()
    -- Create the commit message buffer with placeholder text.
    buffer.new()._type = _L['[hg Commit Buffer]']
    buffer:new_line()
    buffer:new_line()
    buffer:add_text("\z
      HG: Enter commit message.  Lines beginning with 'HG:' are removed.\n\z
      HG: Call `commit()` again on this buffer to commit.\n\z
      HG: Close buffer to abort commit.\n\z
      HG: The files listed below will be included the commit.\n\z
      HG: Removing a listed file will drop it from the commit.\n\z
      HG: --\n\z
      HG: user: "..user.."\n\z
      HG: branch '"..branch.."'\n\z
    ")
    buffer:add_text('HG: '..table.concat(files, '\nHG: '))
    buffer:goto_pos(0)
    buffer._vcs_root = root..'/'
  else
    if ui.dialogs.yesno_msgbox{
         title = _L['Commit?'], informative_text = _L['Proceed with commit?'],
         icon = 'gtk-dialog-question', no_cancel = true
       } ~= 1 then
      return false
    end
    -- Commit the changeset.
    local text = buffer:get_text()
    -- Get the files to commit from the comment text.
    local files = {}
    for action, file in text:gmatch('\r?\nHG:%s+(%l+)%s+([^\r\n]+)') do
      if action == status.M or action == status.A or action == status.R or
         action == status.D then
        files[#files + 1] = root..(not WIN32 and '/' or '\\')..file
      end
    end
    if #files == 0 then ui.print('nothing changed') return false end
    -- Ignore all files starting with 'HG:' as stated.
    text = text:gsub('\r?\nHG:[^\r\n]*', '')
    -- Write the commit message to a file and pass it to hg.
    local logfile = _USERHOME..'/.hg_commit'
    local f = io.open(logfile, 'w')
    f:write(text)
    f:close()
    local p = popen_vcs(M.HG_CMD, 'commit',
                        {repository = root, logfile = logfile},
                        q(table.concat(files, '" "')), '2>&1')
    local out = p:read('*all')
    p:close()
    os.remove(logfile)
    -- Close the commit message buffer on success.
    if out == '' then
      buffer.dirty = false
      io.close_buffer()
    else
      ui.print(out)
    end
    return out == ''
  end
end

-- Reads files and file status from the given `hg` process, shows a
-- filteredlist, and returns the selected file.
-- This only works for `hg` commands that return lines of the form `M foo`.
-- @param p The `hg` process from `popen_vcs()`. It is closed by the function
--   when finished.
-- @return string file selected or nil
-- @see popen_hg
local function select_file(p)
  local files = {}
  for line in p:lines() do
    local status, file = line:match('^(%S+)%s+(.+)$')
    files[#files + 1], files[#files + 2] = status, file
  end
  p:close()
  return ui.filteredlist(_L['File Status'], {_L['Status'], _L['File']},
                         files, false, '--search-column', '1',
                         '--output-column', '1')
end

---
-- Lists files which had or still have conflicts in a filteredlist.
-- The selected file is opened for editing.
-- @name conflicts
function M.conflicts()
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  local file = select_file(popen_vcs(M.HG_CMD, 'resolve',
                                     {repository = root, list = true}))
  if file then io.open_file(root..(not WIN32 and '/' or '\\')..file) end
end

---
-- Shows differences between revisions for the current file or the whole
-- repository.
-- @param all Flag indicating whether or not show differences for the
--   repository. Defaults to `false`.
-- @param opts Optional hg options table.
-- @usage diff(false, {rev = 0}) --> shows file diff to revision 0
-- @usage diff(true, {git = true}) --> shows repo diff in git format
-- @name diff
function M.diff(all, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p = popen_vcs(M.HG_CMD, 'diff', opts, not all and buffer.filename and
                      q(buffer.filename:iconv(_CHARSET, 'UTF-8')) or nil)
  local diff = p:read('*all')
  p:close()
  buffer.new():set_lexer('diff')
  buffer:add_text(diff)
  buffer:goto_pos(0)
  buffer.dirty = false
end

---
-- Shows revision history of the current file or the entire project in a
-- filteredlist.
-- The selected revision is opened in a new buffer for viewing.
-- @param all Flag indicating whether or not to show the repository history
--   instead of file history. Defaults to `false`.
-- @param branch Optional branch name to show history from.
-- @param opts Optional hg options table.
-- @usage log(true, 'foo') --> shows diff for a changeset in branch 'foo'
-- @usage log(false, nil, {reverse = true}) --> shows reverse file diffs
function M.log(all, branch, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  local filename = (buffer.filename or ''):iconv(_CHARSET, 'UTF-8')
  -- Parse the log for the filteredlist.
  local log, changeset = {}, {}
  local p = popen_vcs(M.HG_CMD, 'log', {repository = root, branch = branch},
                      not all and buffer.filename and q(filename) or nil)
  for line in p:lines() do
    local label, line = line:match('^([^:]+):%s+(.+)$')
    if label then
      changeset[label] = line
    else
      log[#log + 1] = changeset.changeset..
                      (changeset.tag and ' ['..changeset.tag..']' or '')..'\n'..
                      changeset.user..' '..changeset.date..'\n'..
                      changeset.summary
    end
  end
  p:close()
  -- Show the filteredlist and open the changeset for the selected commit.
  local rev = ui.filteredlist(_L['hg log'], _L['Changeset'], log)
  if not rev then return end
  rev = tonumber(rev:match('^%d+'))
  if not opts then opts = {repository = root} else opts.repository = root end
  opts[not all and buffer.filename and 'change' or 'rev'] = rev
  if not all and buffer.filename then
    p = popen_vcs(M.HG_CMD, 'diff', opts, q(filename))
  else
    p = popen_vcs(M.HG_CMD, 'export', opts)
  end
  local diff = p:read('*all')
  p:close()
  buffer.new():set_lexer('diff')
  buffer:add_text(diff)
  buffer:goto_pos(0)
  buffer.dirty = false
end

---
-- Merges the working directory with another revision.
-- @param opts Optional hg options table.
function M.merge(opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p = popen_vcs(M.HG_CMD, 'merge', opts)
  ui.print(p:read('*all'))
  p:close()
end

---
-- Pushes changesets to the remote repository.
-- @param opts Optional hg options table.
-- @usage push({force = true}) --> forces push
-- @usage push({branch = 'foo'}) --> pushes branch 'foo'
function M.push(opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p = popen_vcs(M.HG_CMD, 'push', opts)
  ui.print(p:read('*all'))
  p:close()
end

---
-- Pulls changes from the remote repository to the local one.
-- @param opts Optional hg options table.
-- @usage pull({rebase = true}) --> rebases working directory to branch head
function M.pull(opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p = popen_vcs(M.HG_CMD, 'pull', opts)
  ui.print(p:read('*all'))
  p:close()
end

---
-- Marks the current file as having been resolved.
function M.resolve()
  local vcs, root = get_vcs()
  if not root or vcs ~= HG or not buffer.filename then return end
  local p = popen_vcs(M.HG_CMD, 'resolve', {repository = root, mark = true},
                      q(buffer.filename:iconv(_CHARSET, 'UTF-8')), '2>&1')
  local out = p:read('*all')
  p:close()
  if out ~= '' then ui.print(out) end
end

---
-- Restores the current file or repository to its checkout state.
-- @param all Flag indicating whether or not to revert the whole repository.
--   Defaults to `false`.
-- @param opts Optional hg options table.
-- @return `true` on success, `false` otherwise
-- @usage revert(true, {['no-backup'] = true}) --> reverts with no backups
function M.revert(all, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not all and not buffer.filename then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  if all then opts.all = true end
  local p = popen_vcs(M.HG_CMD, 'revert', opts, not all and
                      q(buffer.filename:iconv(_CHARSET, 'UTF-8')) or '', '2>&1')
  local out = p:read('*all')
  p:close()
  io.reload()
  if out ~= '' then ui.print(out) end
  return (not all and out == '') or (all and out ~= '')
end

---
-- Shows status of files in the repository in a filteredlist.
-- The selected file is opened for editing.
-- @param opts Optional hg options table.
function M.status(opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local file = select_file(popen_vcs(M.HG_CMD, 'status', opts))
  if file then io.open_file(root..(not WIN32 and '/' or '\\')..file) end
end

---
-- Summarizes working directory state in a message box.
function M.summary()
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  local p = popen_vcs(M.HG_CMD, 'summary', {repository = root})
  ui.dialogs.msgbox{
    title = _L['hg summary'], informative_text = p:read('*all'),
    icon = 'gtk-dialog-info'
  }
  p:close()
end

---
-- Names a particular revision using the given name.
-- @param name The name for a revision.
-- @param opts Optional hg options table.
-- @usage tag('foo', {rev = 10}) --> tags revision 10 as 'foo'
-- @usage tag('foo', {remove = true}) --> removes 'foo' tag
function M.tag(name, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG or not name then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p = popen_vcs(M.HG_CMD, 'tag', opts, q(name))
  local out = p:read('*all')
  p:close()
  if out ~= '' then ui.print(out) end
end

---
-- Updates working directory (or switches revisions)
-- @param branch Optional named branch to update to.
-- @param opts Optional hg options table.
-- @usage update('foo', {rev = 10}) --> updates to rev 10 in branch 'foo'
function M.update(branch, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= HG then return end
  if not opts then opts = {repository = root} else opts.repository = root end
  local p, cmd = popen_vcs(M.HG_CMD, 'update', opts,
                           branch and q(branch) or nil)
  ui.print('> '..cmd)
  ui.print(p:read('*all'))
  p:close()
end

return M
