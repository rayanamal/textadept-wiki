-- Copyright 2012-2013 Mitchell mitchell.att.foicica.com. See LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- The version control module.
module('_M.version_control')]]

-- Markdown:
-- # Settings
--
-- * `BZR` [string] (Read-only)
--   Identifier for the bzr version control system.
-- * `GIT` [string] (Read-only)
--   Identifier for the git version control system.
-- * `HG` [string] (Read-only)
--   Identifier for the mercurial version control system.
-- * `SVN` [string] (Read-only)
--   Identifier for the subversion version control system.
-- * `CVS` [string] (Read-only)
--   Identifier for the cvs version control system.

M.BZR = 'bzr'
M.GIT = 'git'
M.HG = 'hg'
M.SVN = 'svn'
M.CVS = 'cvs'

---
-- Version control system names with their associated directories.
-- @class table
-- @name VCS
M.VCS = {
  [M.BZR] = '.bzr', [M.GIT] = '.git', [M.HG] = '.hg', [M.SVN] = '.svn',
  [M.CVS] = 'CVS'
}

-- Localizations.
local _L = _L
if _L['No repository here']:find('^No Localization') then
  _L['No repository here'] = 'No repository here'
  _L['Repository Command'] = 'Repository Command'
end

---
-- Get the version control system (VCS) and the root directory for a project.
-- For most VCS's, the directory tree is walked up until a VCS directory is
-- found and snapopens all files below the parent directory. For SVN and CVS,
-- the directory tree is walked up until no VCS directory is found.
-- @param utf8_path A UTF-8 string directory path that is part of the project.
--   If nil, uses the current buffer's filename or the directory of the last
--   open buffer.
-- @return string VCS identifier and project root directory
-- @name get_vcs
function M.get_vcs(utf8_path)
  if not utf8_path then utf8_path = buffer.filename or lfs.currentdir()..'/' end
  local dir, vcs, root = utf8_path:match('^(.+)[/\\]'), nil, nil
  local lfs_attributes = lfs.attributes
  while dir do
    for name, vc in pairs(M.VCS) do
      if lfs_attributes(dir..'/'..vc, 'mode') == 'directory' then
        vcs, root = name, dir
        break
      end
    end
    if vcs and vcs ~= 'svn' and vcs ~= 'cvs' then break end
    dir = dir:match('^(.+)[/\\]')
  end
  return vcs, root
end

---
-- Quickly open files in a project.
-- @param utf8_path A UTF-8 string directory path that is part of the project.
--   If nil, uses the current buffer's filename or the directory of the last
--   open buffer.
-- @see get_vcs
-- @see io.snapopen
-- @name open_in_project
function M.snapopen_project(utf8_path)
  local vcs, root = M.get_vcs(utf8_path)
  if vcs and root then
    _M.version_control[vcs] = require('version_control.'..vcs)
    local filter = _M.version_control[vcs]._FILTER
    if filter and type(filter) == 'function' then filter = filter(root) end
    io.snapopen(root, filter)
  end
end

---
-- Execute a VCS command from a filteredlist.
-- @param utf8_path An optional UTF-8 string directory path that is part of the
--   project. If nil, uses the current buffer's filename or the directory of the
--   last open buffer.
function M.command(utf8_path)
  local vcs, root = M.get_vcs(utf8_path)
  if not vcs or not root then
    ui.dialogs.msgbox{
      title = _L['No repository here'],
      informative_text = _L['No repository here'], icon = 'gtk-dialog-error'
    }
    return
  end
  _M.version_control[vcs] = require('version_control.'..vcs)
  local commands = {}
  for command in pairs(_M.version_control[vcs]) do
    if command:find('^[%l_]+$') then commands[#commands + 1] = command end
  end
  table.sort(commands)
  local buttons, i = ui.dialogs.filteredlist{
    title = root, columns = _L['Repository Command'], items = commands
  }
  if buttons == 1 and i then _M.version_control[vcs][commands[i]]() end
end

---
-- Surrounds the given string in double quotes.
-- Used primarily for quoting parameters passed to a command-line VCS client.
-- @param str The string to quote.
-- @return string
function M.q(str) return '"'..str..'"' end

-- Converts a VCS client options table to a command line string for use with
-- the command-line VCS client.
-- @param opts Table of options. Keys are switches accepted by client commands
--   with associated values. Switches with no parameters have `true` values,
--   switches with numeric parameters have numeric values, switches with string
--   parameters have string values that are automatically quoted, and switches
--   specified multiple times have table values containing arguments.
-- @return command line string
-- @usage tocmdline{repository = '/tmp/foo', verbose = true} -->
--   '--repository "/tmp/foo" --verbose'
-- @usage tocmdline{repository = '/tmp/foo', rev = {10, 20}} -->
--   '--repository "/tmp/foo" --rev 10 --rev 20'
-- @see popen_vcs
local function tocmdline(opts)
  if not opts then return '' end
  if type(opts) ~= 'table' then return tostring(opts) end
  local q = M.q
  local args = {}
  for opt, value in pairs(opts) do
    if value == true then
      args[#args + 1] = '--'..opt
    elseif type(value) == 'number' then
      args[#args + 1] = '--'..opt..' '..value
    elseif type(value) == 'string' then
      args[#args + 1] = '--'..opt..' '..q(value)
    elseif type(value) == 'table' then
      args[#args + 1] = ''
      for i = 1, #value do
        if type(value[i]) == 'number' then
          args[#args] = args[#args]..' --'..opt..' '..value[i]
        elseif type(value[i]) == 'string' then
          args[#args] = args[#args]..' --'..opt..' '..q(value[i])
        end
      end
    end
  end
  return table.concat(args, ' ')
end

---
-- Calls the command-line VCS client with the given command and options and
-- returns the process to read stdout from (via `io.popen`).
-- @param vcs String name of the command-line VCS client.
-- @param cmd String command (e.g. 'add', 'annotate', etc.).
-- @param opts Table of options for the hg command.
-- @param ... Other things to pass to the VCS client.
-- @return file handle, cmdline string
-- @name popen_vcs
function M.popen_vcs(vcs, cmd, opts, ...)
  local cmdline = vcs..' '..cmd..' '..tocmdline(opts)..' '..
                  table.concat({...}, ' ')
  return io.popen(cmdline), cmdline
end

return M
