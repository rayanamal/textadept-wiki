-- Copyright 2012-2013 Mitchell mitchell.att.foicica.com. See LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- Subversion for the version control module.
module('_M.version_control.svn')]]

-- Markdown:
-- # Settings
--
-- * `SVN_CMD` [string]: The Subversion executable for your platform.
-- * `SVN_IGNORE` [string]: The name of the file for ignoring repository files.

M.SVN_CMD = 'svn'
M.SVN_IGNORE = '.svnignore'

-- Localizations.
local _L = _L
if _L['[svn Commit Buffer]']:find('^No Localization') then
  _L['[svn Commit Buffer]'] = '[svn Commit Buffer]'
  _L['svn log'] = 'svn log'
  _L['Changeset'] = 'Changeset'
  _L['File Status'] = 'File Status'
  _L['Status'] = 'Status'
  _L['Revision'] = 'Revision'
end

local vcs = _M.version_control
local get_vcs, SVN, popen_vcs, q = vcs.get_vcs, vcs.SVN, vcs.popen_vcs, vcs.q
local events, events_connect = events, events.connect

-- Map of shell-style glob characters to Lua pattern characters.
-- @class table
-- @name lua_patt
local lua_patt = {
  ['\\'] = '%', ['*'] = '.*', ['/'] = '[/\\]'
}

---
-- Generates a snapopen filter based on a project's ".svnignore" file.
-- The ignore file is arbitrary and not part of SVN. For now, directory
-- `svn:ignore` properties are not read.
-- @param root The path of the project's root directory.
-- @see io.snapopen
-- @return filter table
function M._FILTER(root)
  local f = io.open(root..'/'..M.SVN_IGNORE)
  if not f then return nil end
  local filter = { extensions = {}, folders = {} }
  for line in f:lines() do
    if line ~= '' then
      local ext = line:match('^%s*%*%.([%w-]+)$')
      if ext then
        filter.extensions[#filter.extensions + 1] = ext
      else
        -- Convert glob to Lua pattern.
        filter[#filter + 1] = line:gsub('[\\*/]', lua_patt)
      end
    end
  end
  f:close()
  return filter
end

function M.add()

end

function M.annotate()

end

function M.cleanup()

end

function M.commit()

end

---
-- Shows differences between revisions for the current file or the whole
-- repository.
-- @param all Flag indicating whether or not show differences for the
--   repository. Defaults to `false`.
-- @param opts Optional svn options table.
-- @usage diff(false, {revision = 1}) --> shows file diff to revision 1
-- @usage diff(true, {git = true}) --> shows repo diff in git format
-- @name diff
function M.diff(all, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= SVN then return end
  if not opts then opts = {} end
  local p = popen_vcs(M.SVN_CMD, 'diff', opts, not all and buffer.filename and
                      q(buffer.filename:iconv(_CHARSET, 'UTF-8')) or q(root))
  local diff = p:read('*all')
  p:close()
  buffer.new():set_lexer('diff')
  buffer:add_text(diff)
  buffer:goto_pos(0)
  buffer.dirty = false
end

function M.lock()

end

---
-- Shows revision history of the current file or the entire project in a
-- filteredlist.
-- The selected revision is opened in a new buffer for viewing.
-- @param all Flag indicating whether or not to show the repository history
--   instead of file history. Defaults to `false`.
-- @param opts Optional svn options table.
-- @name log
function M.log(all, opts)
  local vcs, root = get_vcs()
  if not root or vcs ~= SVN then return end
  local filename = (buffer.filename or ''):iconv(_CHARSET, 'UTF-8')
  -- Parse the log for the filteredlist.
  local log, changeset = {}, {}
  local p = popen_vcs(M.SVN_CMD, 'log', nil,
                      not all and buffer.filename and q(filename) or nil)
  for line in p:lines() do
    if line:find('^r%d+%s|') then
      local rev, user, date = line:match('^r(%d+)%s|%s([^|]+)|%s([^|]+)')
      changeset.revision, changeset.user, changeset.date = rev, user, date
    elseif line ~= '' and not line:find('^%-+$') then
      changeset.summary = line
    elseif line ~= '' then
      if changeset.revision then
        log[#log + 1] = changeset.revision..'\n'..
                        changeset.user..changeset.date..'\n'..
                        changeset.summary
      end
    end
  end
  p:close()
  -- Show the filteredlist and open the changeset for the selected commit.
  local rev = ui.filteredlist(_L['svn log'], _L['Changeset'], log)
  if not rev then return end
  rev = tonumber(rev:match('^%d+'))
  if not opts then opts = {change = rev} else opts.change = rev end
  if not all and buffer.filename then
    p = popen_vcs(M.SVN_CMD, 'diff', opts, q(filename))
  else
    opts.diff = true
    p = popen_vcs(M.SVN_CMD, 'log', opts, q(root))
  end
  local diff = p:read('*all')
  p:close()
  buffer.new():set_lexer('diff')
  buffer:add_text(diff)
  buffer:goto_pos(0)
  buffer.dirty = false
end

function M.merge()

end

function M.patch()

end

function M.resolve()

end

function M.resolved()

end

function M.revert()

end

---
-- Shows status of files in the repository in a filteredlist.
-- The selected file is opened for editing.
-- @param opts Optional svn options table.
function M.status()
  local vcs, root = get_vcs()
  if not root or vcs ~= SVN then return end
  if not opts then opts = {} end
  opts['show-updates'] = true
  local files = {}
  local p = popen_vcs(M.SVN_CMD, 'status', opts)
  for line in p:lines() do
    local status, rev, file = line:match('^(.........)%s+(%d+)%s+(.+)$')
    files[#files + 1], files[#files + 2], files[#files + 3] = status, rev, file
  end
  p:close()
  local file = ui.filteredlist(_L['File Status'],
                               {_L['Status'], _L['Revision'], _L['File']},
                               files, false, '--search-column', '2',
                               '--output-column', '2')
  if file then io.open_file(root..(not WIN32 and '/' or '\\')..file) end
end

function M.switch()

end

function M.unlock()

end

function M.update()

end

return M
