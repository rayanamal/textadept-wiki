-- Copyright 2007-2009 Mitchell Foral mitchell<att>caladbolg.net. See LICENSE.
-- Dark lexer theme for Textadept.

--#!/usr/bin/env python
--
--import math
--
--def hsvrgb(h, s, v):
--	s = s / 100.0
--	v = v / 100.0
--
--	hi = math.floor(h / 60.) % 6
--	f = float((h / 60.) - math.floor(h / 60.))
--	p = v * (1.0 - s)
--	q = v * (1.0 - (f * s))
--	t = v * (1.0 - ((1.0 - f) * s))
--
--	v = int(v * 256)
--	t = int(t * 256)
--	q = int(q * 256)
--	p = int(p * 256)
--
--	if hi == 0:
--		return (v, t, p)
--	elif hi == 1:
--		return (q, v, p)
--	elif hi == 2:
--		return (p, v, t)
--	elif hi == 3:
--		return (p, q, v)
--	elif hi == 4:
--		return (t, p, v)
--	elif hi == 5:
--		return (v, p, q)
--
--def generateColorScheme(s, v):
--	print "colors = {"
--	print "\tred = color('%02x', '%02x', '%02x')," % hsvrgb(0, s, v)
--	print "\torange = color('%02x', '%02x', '%02x')," % hsvrgb(30, s, v)
--	print "\tyellow = color('%02x', '%02x', '%02x')," % hsvrgb(60, s, v)
--	print "\tchartreuse = color('%02x', '%02x', '%02x')," % hsvrgb(90, s, v)
--	print "\tgreen = color('%02x', '%02x', '%02x')," % hsvrgb(120, s, v)
--	print "\taquamarine = color('%02x', '%02x', '%02x')," % hsvrgb(150, s, v)
--	print "\tcyan = color('%02x', '%02x', '%02x')," % hsvrgb(180, s, v)
--	print "\tazure = color('%02x', '%02x', '%02x')," % hsvrgb(210, s, v)
--	print "\tblue = color('%02x', '%02x', '%02x')," % hsvrgb(240, s, v)
--	print "\tviolet = color('%02x', '%02x', '%02x')," % hsvrgb(270, s, v)
--	print "\tmagenta = color('%02x', '%02x', '%02x')," % hsvrgb(300, s, v)
--	print "\trose = color('%02x', '%02x', '%02x')," % hsvrgb(330, s, v)
--	print "}"
--
--def main():
--	print "saturation:",
--	s = int(raw_input())
--	print "value:",
--	v = int(raw_input())
--	generateColorScheme(s, v)
--
--
--if __name__ == "__main__":
--	main()


module('lexer', package.seeall)
colors = {
	text = color('99', '99', '99'),
	background = color('28', '28', '28'),
	darkgrey = color('1f', '1f', '1f'),
	lightgrey = color('bb', 'bb', 'bb'),
	white = color('ff', 'ff', 'ff'),
	black = color('00', '00', '00'),

	-- Auto-generated colors
	red = color('d9', '57', '57'),
	orange = color('d9', '98', '57'),
	yellow = color('d9', 'd9', '57'),
	chartreuse = color('98', 'd9', '57'),
	green = color('57', 'd9', '57'),
	aquamarine = color('57', 'd9', '98'),
	cyan = color('57', 'd9', 'd9'),
	azure = color('57', '98', 'd9'),
	blue = color('57', '57', 'd9'),
	violet = color('98', '57', 'd9'),
	magenta = color('d9', '57', 'd9'),
	rose = color('d9', '57', '98'),

}

style_nothing     = style {                                         }
style_char        = style { fore = colors.red,     bold      = true }
style_class       = style { fore = colors.white, bold = true, underline = true }
style_comment     = style { fore = colors.azure,    italic    = true }
style_constant    = style { fore = colors.cyan,    bold      = true }
style_definition  = style { fore = colors.violet,     bold      = true }
style_error       = style { fore = colors.red, bold = true, italic = true, underline = true }
style_function    = style { fore = colors.orange,                      }
style_keyword     = style { fore = colors.white,   bold      = true }
style_number      = style { fore = colors.rose,    bold      = true }
style_operator    = style { fore = colors.lightgrey,    bold      = true }
style_string      = style { fore = colors.chartreuse, italic = true  }
style_preproc     = style { fore = colors.magenta, bold      = true }
style_tag         = style { fore = colors.white,    bold      = true }
style_type        = style { fore = colors.green, bold        = true }
style_variable    = style { fore = colors.normal,  italic    = true }
style_embedded    = style_tag..{ back = color('44', '44', '44')     }
style_highlighted = style { back = colors.orange                     }
style_identifier  = style_nothing

-- Default styles.
local font_face = '!DejaVu Sans Mono'--'!Liberation Mono'
local font_size = 10
if WIN32 then
  font_face = '!Courier New'
elseif MAC then
  font_face = '!Monaco'
  font_size = 12
end
style_default = style{
  font = font_face,
  size = font_size,
  fore = colors.text,
  back = colors.background
}
style_line_number = style { fore = colors.text, back = colors.darkgrey}
style_bracelight  = style { fore = colors.black, back = colors.green, bold = true }
style_bracebad    = style { fore = colors.black, back = colors.red, bold = true }
style_controlchar = style_nothing
style_indentguide = style { fore = colors.darkgrey, back = colors.white }
style_calltip     = style { fore = colors.white, back = colors.black }
