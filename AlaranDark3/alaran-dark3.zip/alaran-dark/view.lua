-- Copyright 2007-2009 Mitchell Foral mitchell<att>caladbolg.net. See LICENSE.
-- Dark editor theme for Textadept.

local c = _SCINTILLA.constants
local buffer = buffer

-- caret
buffer.caret_fore = 0xaaaaaa
buffer.caret_line_visible = true
buffer.caret_line_back = 0x333333
caret_line_back_alpha = 256
buffer:set_x_caret_policy(1, 20) -- CARET_SLOP
buffer:set_y_caret_policy(13, 1) -- CARET_SLOP | CARET_STRICT | CARET_EVEN

-- selection
buffer:set_sel_fore(1, 0x141414)
buffer:set_sel_back(1, 0x999999) -- 0x99 | 0x99 << 8 | 0x99 << 16

buffer.margin_width_n[0] = 4 + 4 * -- line number margin
  buffer:text_width(c.STYLE_LINENUMBER, '9')

buffer.margin_width_n[1] = 10

-- fold margin
buffer:set_fold_margin_colour(1, 11184810) -- 0xAA | 0xAA << 8 | 0xAA << 16
buffer:set_fold_margin_hi_colour(1, 11184810) -- 0xAA | 0xAA << 8 | 0xAA << 16
buffer.margin_type_n[2] = c.SC_MARGIN_SYMBOL
buffer.margin_width_n[2] = 10
buffer.margin_mask_n[2] = c.SC_MASK_FOLDERS
buffer.margin_sensitive_n[2] = true

-- fold margin markers
buffer:marker_define(c.SC_MARKNUM_FOLDEROPEN, c.SC_MARK_BOXMINUS)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDEROPEN, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDEROPEN, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDER, c.SC_MARK_BOXPLUS)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDER, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDER, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDERSUB, c.SC_MARK_VLINE)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDERSUB, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDERSUB, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDERTAIL, c.SC_MARK_LCORNER)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDERTAIL, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDERTAIL, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDEREND, c.SC_MARK_BOXPLUSCONNECTED)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDEREND, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDEREND, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDEROPENMID, c.SC_MARK_BOXMINUSCONNECTED)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDEROPENMID, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDEROPENMID, 0x000000)

buffer:marker_define(c.SC_MARKNUM_FOLDERMIDTAIL, c.SC_MARK_TCORNER)
buffer:marker_set_fore(c.SC_MARKNUM_FOLDERMIDTAIL, 0xffffff)
buffer:marker_set_back(c.SC_MARKNUM_FOLDERMIDTAIL, 0x000000)

-- various
buffer.call_tip_use_style = 0
buffer:set_fold_flags(17)
buffer.mod_event_mask = c.SC_MOD_CHANGEFOLD
buffer.two_phase_draw = true
