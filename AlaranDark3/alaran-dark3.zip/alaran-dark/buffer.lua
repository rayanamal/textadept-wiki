-- Copyright 2007-2009 Mitchell Foral mitchell<att>caladbolg.net. See LICENSE.
-- SciTE editor theme for Textadept.

local buffer = buffer

-- folding
buffer.property['fold'] = '1'
buffer.property['fold.by.indentation'] = '1'

-- tabs and indentation
buffer.tab_width = 4
buffer.use_tabs = true
buffer.indent = 4
buffer.tab_indents = true
buffer.back_space_un_indents = true
buffer.indentation_guides = 0

-- various
buffer.auto_c_choose_single = true
buffer.auto_c_max_width = 60
buffer.auto_c_max_height = 10

-- column marker
buffer.edge_column = 80
buffer.edge_mode = 1

-- Map to the Meta key so that multi-select can actually work.
buffer.rectangular_selection_modifier = 8
buffer.multiple_selection = true
buffer.multi_paste = 1
buffer.additional_selection_typing = true
buffer.additional_carets_visible = true

buffer.wrap_visual_flags = 1
buffer.wrap_visual_flags_location = 1

buffer.call_tip_fore_hlt = 0x5798d9
