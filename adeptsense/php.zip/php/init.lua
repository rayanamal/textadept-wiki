-- Copyright 2007-2014 Mitchell mitchell.att.foicica.com. See LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- The php module.
-- It provides utilities for editing PHP code.
--
-- ## Key Bindings
--
-- + `Ctrl+L, M` (`⌘L, M` on Mac OSX | `M-L, M` in curses)
--   Open this module for editing.
-- + `->`
--   When to the right of a known symbol, show an autocompletion list of fields
--   and functions.
-- + `::`
--   When to the right of a known symbol, show an autocompletion list of fields
--   and functions.
-- + `Shift+Enter` (`⇧↩` | `S-Enter`)
--   Add ';' to the end of the current line and insert a newline.
-- @field sense
--   The PHP [Adeptsense](textadept.adeptsense.html).
--   It loads user tags from *`_USERHOME`/modules/php/tags* and user apidocs
--   from *`_USERHOME`/modules/php/api*.
module('_M.php')]]

-- Adeptsense.

M.sense = textadept.adeptsense.new('php')
M.sense.syntax.symbol_chars = '[%w_%->:]'
local as = textadept.adeptsense
M.sense.ctags_kinds = {
  c = as.CLASS, i = as.CLASS, d = as.FIELD, f = as.FUNCTION, j = as.FUNCTION,
  v = as.FIELD
}
M.sense:load_ctags(_HOME..'/modules/php/tags', true)
M.sense.api_files = {_HOME..'/modules/php/api'}
M.sense.syntax.type_declarations = {}
M.sense:add_trigger('->')
M.sense:add_trigger('::')

-- Load user tags and apidoc.
if lfs.attributes(_USERHOME..'/modules/php/tags') then
  M.sense:load_ctags(_USERHOME..'/modules/php/tags')
end
if lfs.attributes(_USERHOME..'/modules/php/api') then
  M.sense.api_files[#M.sense.api_files + 1] = _USERHOME..'/modules/php/api'
end

-- Commands.

-- Show syntax errors as annotations.
events.connect(events.FILE_AFTER_SAVE, function()
  if buffer:get_lexer() == 'php' then
    buffer:annotation_clear_all()
    local p = io.popen('php -l "'..buffer.filename..'" -f 2>&1')
    local out = p:read('*all')
    p:close()
    if not out:match('^No syntax errors') then
      local filename = buffer.filename:gsub('([%.+*%(%)%[%]-])', '%%%1')
      local err_msg, line = out:match('^PHP (.-) in '..
                                      filename..' on line (%d+)')
      if line then
        buffer.annotation_visible = 2
        buffer.annotation_text[line - 1] = err_msg
        buffer.annotation_style[line - 1] = 8 -- error style number
        buffer:goto_line(line - 1)
      end
    end
  end
end)

---
-- Container for PHP-specific key bindings.
-- @class table
-- @name _G.keys.php
keys.php = {
  [keys.LANGUAGE_MODULE_PREFIX] = {
    m = {io.open_file, _HOME..'/modules/php/init.lua'},
  },
  ['s\n'] = function()
    buffer:line_end()
    buffer:add_text(';')
    buffer:new_line()
  end,
}

-- Snippets.

---
-- Container for PHP-specific snippets.
-- @class table
-- @name _G.snippets.php
if type(snippets) == 'table' then
  snippets.php = {

  }
end

return M
