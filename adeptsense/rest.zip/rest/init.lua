-- Copyright 2007-2014 Mitchell mitchell.att.foicica.com. See LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- The reST module.
-- It provides utilities for editing reST and Sphinx documents.
--
-- ## Key Bindings
--
-- + `Ctrl+L, M` (`⌘L, M` on Mac OSX | `M-L, M` in curses)
--   Open this module for editing.
-- + `Ctrl+L, G` (`⌘L, G` | `M-L, G`)
--   Jump to the selected section.
-- + `Ctrl+L, O` (`⌘L, O` | `M-L, O`)
--   Open the image specified by the directive on the current line.
--
-- @field sense
--   The reST [Adeptsense](textadept.adeptsense.html).
--   It loads user tags from *`_USERHOME`/modules/rest/tags* and user apidocs
--   from *`_USERHOME`/modules/rest/api*.
-- @field DOCUTILS_PATH (string)
--   The absolute path to the directory that contains the Python [Docutils][]
--   library if it is not in the environment's `PYTHONPATH`.
--   The default value is `nil`, which indicates Docutils is installed.
--
--   [Docutils]: http://docutils.sourceforge.net/
module('_M.rest')]]

M.DOCUTILS_PATH = nil

-- Adeptsense.

M.sense = textadept.adeptsense.new('rest')
M.sense.api_files = {_HOME..'/modules/rest/api'}
M.sense:add_trigger('. ') -- full ".. " is unnecessary
M.sense:add_trigger(':')

-- Fake set of ctags.
-- d and D are Docutils and Sphinx directives, respectively.
-- o and O are Docutils and Sphinx directive options, respectively.
-- r and R are Docutils and Sphinx roles, respectively.
local as = textadept.adeptsense
M.sense.ctags_kinds = {
  d = as.FUNCTION, D = as.FUNCTION, o = as.FIELD, O = as.FIELD, r = as.FIELD,
  R = as.FIELD
}
M.sense:load_ctags(_HOME..'/modules/rest/tags', true)

-- Returns the full symbol and the current symbol part behind the caret.
-- Identifies the symbol behind the caret as either a directive, parameter, or
-- role.
function M.sense:get_symbol()
  local line, pos = buffer:get_cur_line()
  local line_part = line:sub(1, pos)
  local part = line_part:match('[%w-]*$')
  if line_part:find('^%s*%.%. [%w-]*$') then
    -- Directive.
    return '', part
  elseif line_part:find('^%s*:[%w-]*$') then
    -- Parameter or role.
    local line_num = buffer:line_from_position(buffer.current_pos) - 1
    for i = line_num, 0, -1 do
      line = buffer:get_line(i)
      local directive = line:match('^%s*%.%. ([%w-]+)::[ \r\n]')
      if directive then return directive, part end -- parameter
      if not line:find('^%s*:') then return '', part end -- role
    end
  elseif line_part:find('%s+:[%w-]*$') then
    -- Role.
    return '', part
  end
  return nil
end

-- Returns the list of completions for string *symbol*.
-- Appends '::' or ':' to the default list of completions, depending on whether
-- or not symbol is a directive, option, or role.
function M.sense:get_completions(symbol, ofields, ofuncs)
  local cmpls = self.super.get_completions(self, symbol, ofields, ofuncs)
  if not cmpls then return nil end
  for i = 1, #cmpls do
    cmpls[i] = cmpls[i]:gsub('?', ofuncs and '::?' or ':?')
  end
  return cmpls
end

-- Shows an autocompletion list for the symbol behind the caret.
-- If the symbol is a directive, only display directives. Otherwise, display
-- options and roles.
function M.sense:complete(only_fields, only_functions)
  local line, pos = buffer:get_cur_line()
  local directive = line:sub(1, pos):find('^%s*%.%. [%w-]*$')
  return self.super.complete(self, not directive, directive)
end

-- Commands.

-- Add '`' to autopaired and typeover characters.
textadept.editing.char_matches.rest = {
  [40] = ')', [91] = ']', [123] = '}', [39] = "'", [34] = '"', [96] = '`'
}
textadept.editing.typeover_chars = {
  [41] = 1, [93] = 1, [125] = 1, [39] = 1, [34] = 1, [96] = 1
}

-- Enable folding by the Sphinx convention for detected Sphinx files:
-- # > * > = > - > ^ > ".
events.connect(events.LEXER_LOADED, function(lexer)
  if lexer == 'rest' and buffer:get_line(0):find('^%s*%.%. .-sphinx') then
    buffer.property['fold.by.sphinx.convention'] = '1'
    buffer:colourise(0, buffer.end_styled)
  end
end)

local cmd = 'python "'.._HOME..'/modules/rest/rst2pseudoxml.py" '..
            '--report=2 --halt=5 "%s"'
-- Show syntax errors as annotations.
events.connect(events.FILE_AFTER_SAVE, function()
  if buffer:get_lexer() ~= 'rest' then return end
  buffer:annotation_clear_all()
  buffer.annotation_visible = buffer.ANNOTATION_BOXED
  local jumped = false
  local filename = buffer.filename:iconv(_CHARSET, 'UTF-8')
  spawn(cmd:format(filename), M.DOCUTILS_PATH, nil, function(chunk)
    for line in chunk:gmatch('[^\r\n]+') do
      local line_num, msg = line:match('^[^:]+:(%d+):%s*(.+)$')
      if line_num and msg and
         (msg:find('WARNING') or msg:find('ERROR') or msg:find('SEVERE')) then
        if msg:find('Unknown interpreted text role') then
          -- Ignore role errors when it comes to Sphinx roles.
          -- TODO: determine if the document is Sphinx or not?
          for i = 1, #sphinx_roles do
            if msg:find('"'..sphinx_roles[i]..'"') then goto continue end
          end
        end
        buffer.annotation_text[line_num - 1] = msg
        buffer.annotation_style[line_num - 1] = 8 -- error style number
        if not jumped then
          buffer:goto_line(line_num - 1)
          jumped = true
        end
        ::continue::
      end
    end
  end):wait()
end)

---
-- Prompts the user to select a section title to jump to.
-- Requires the entire document to be styled.
function M.goto_section()
  if buffer.end_styled < buffer.length - 1 then
    buffer:colourise(0, buffer.length - 1)
  end
  local items = {}
  for i = 0, buffer.line_count - 2 do
    if bit32.band(buffer.fold_level[i + 1], buffer.FOLDLEVELHEADERFLAG) > 0 then
      local name = buffer:get_line(i + 1):match('^.')..
                   buffer:get_line(i):match('^[^\r\n]*')
      if name then items[#items + 1], items[#items + 2] = i + 1, name end
    end
  end
  local button, i = ui.dialogs.filteredlist{
    title = 'Goto Section', columns = {'Line', 'Name'}, items = items,
    search_column = 2, string_output = true
  }
  if button ~= _L['_OK'] then return end
  textadept.editing.goto_line(tonumber(i))
end

---
-- Opens the image specified in an "image" or "figure" directive on the current
-- line.
function M.open_image()
  local line = buffer:get_cur_line()
  local file = line:match('^%s*%.%. image::%s+(%S+)') or
               line:match('^%s*%.%. figure::%s+(%S+)')
  if not file or not buffer.filename then return end
  local cmd = 'xdg-open "%s"'
  if WIN32 then
    cmd = 'start "" "%s"'
  elseif OSX then
    cmd = 'open "file://%s"'
  end
  spawn(cmd:format(buffer.filename:match('^.+[/\\]')..file))
end

---
-- Container for reST-specific key bindings.
-- @class table
-- @name _G.keys.rest
keys.rest = {
  [keys.LANGUAGE_MODULE_PREFIX] = {
    m = {io.open_file, _HOME..'/modules/rest/init.lua'},
    g = M.goto_section,
    o = M.open_image,
  }
}

-- Snippets.

if type(snippets) == 'table' then
---
-- Container for reST-specific snippets.
-- @class table
-- @name _G.snippets.rest
  snippets.rest = {
    attention = [[
.. attention::
   %0
]],
    danger = [[
.. danger::
   %0
]],
    error = [[
.. error::
   %0
]],
    hint = [[
.. hint::
   %0
]],
    important = [[
.. important::
   %0
]],
    note = [[
.. note::
   %0
]],
    tip = [[
.. tip::
   %0
]],
    warning = [[
.. warning::
   %0
]],
    admonition = [[
.. admonition:: %1(title)
   %0
]],
    image = [[
.. image:: %1(picture.jpg)
   :height: %2(100px)
   :width: %3(200px)
   :scale: %4(50%%)
   :alt: %5(alternate text)
   :align: %6(right)
]],

    figure = [[
.. figure:: %1(picture.jpg)
   :height: %2(100px)
   :width: %3(200px)
   :scale: %4(50%%)
   :alt: %5(alternate text)
   :align: %6(right)
   :figwidth: %7(figure width)
   :figclass: %8(figure class)

   %9(caption)

   %10(legend)

]],

    codeblock = [[
.. code-block:: %1(language)
   %2(:linenos:

   )%0
]],
    footnote = [[[#f%1(number)]_


.. rubric:: %2(Footnotes)

.. [#f1] Text of the first footnote.
.. [#f2] Text of the second footnote.

]],

    replace = [[
.. |%1(name)| replace:: %2(replacement *text*)

]],

    repeatingimage = [[
.. |%1(caution)| image:: %2(warning.png)
   :height: %3(100px)
   :width: %4(200px)
   :scale: %5(50%%)
   :alt: %6(warning)
   :align: %7(right)
]],

    comment = ".. %0",

    anchor = [[
.. _`%1(anchor)`: ]],

    reference = [[:ref:`%1(anchor)`]],

    emphasis = [[*%1(text)*]],
    strong_emphasis = [[**%1(text)**]],
    code = [[``%1(text)``]],
    external_link_together = [[`%1(link text) <%2(http://example.com/)>`_]],
    external_link_separated = [[`%1(link text)`_

.. _`%1`: %2(http://example.com/)]],
  }
end

return M
