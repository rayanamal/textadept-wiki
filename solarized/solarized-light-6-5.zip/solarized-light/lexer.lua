-- Copyright 2007-2011 Mitchell mitchell<att>caladbolg.net. See LICENSE.
-- Dark lexer theme for Textadept.

-- Modified by Brian Schott. Colors based on the Solarized theme by
-- Ethan Schoonover http://ethanschoonover.com/solarized

-- Please note this theme is in a separate Lua state than Textadept's main one.
-- This means the global variables like 'buffer', 'view', and 'gui' are not
-- available here. Only the variables in the 'lexer' module are.

-- module('lexer', package.seeall)

local l, color, style = lexer, lexer.color, lexer.style

l.colors = {
  base03      = color("00", "2b", "36"),
  base02      = color("07", "36", "42"),
  base01      = color("58", "6e", "75"),
  base00      = color("65", "7b", "83"),
  base0       = color("83", "94", "96"),
  base1       = color("93", "a1", "a1"),
  base2       = color("ee", "e8", "d5"),
  base3       = color("fd", "f6", "e3"),
  yellow      = color("b5", "89", "00"),
  orange      = color("cb", "4b", "16"),
  red         = color("dc", "32", "2f"),
  magenta     = color("d3", "36", "82"),
  violet      = color("6c", "71", "c4"),
  blue        = color("26", "8b", "d2"),
  cyan        = color("2a", "a1", "98"),
  green       = color("85", "99", "00"),
}

l.style_nothing     = style {                                           }
l.style_char        = style { fore = l.colors.red,     bold      = true }
l.style_class       = style { fore = l.colors.violet,  underline = true, bold = true}
l.style_comment     = style { fore = l.colors.base1,   italic    = true }
l.style_constant    = style { fore = l.colors.teal,    bold      = true }
l.style_definition  = style { fore = l.colors.red,     bold      = true }
l.style_error       = style { fore = l.colors.red,     italic    = true }
l.style_function    = style { fore = l.colors.blue,    bold      = true }
l.style_keyword     = style { fore = l.colors.green,   bold      = true }
l.style_number      = style { fore = l.colors.cyan                      }
l.style_operator    = style { fore = l.colors.base01,  bold      = true }
l.style_string      = style { fore = l.colors.cyan,    italic    = true }
l.style_preproc     = style { fore = l.colors.magenta, bold      = true }
l.style_tag         = style { fore = l.colors.blue,    bold      = true }
l.style_type        = style { fore = l.colors.yellow                    }
l.style_variable    = style { fore = l.colors.white,   italic    = true }
l.style_whitespace  = style {                                           }
l.style_embedded    = l.style_tag..{ back = color('44', '44', '44')       }
l.style_identifier  = l.style_nothing

-- Default styles.
local font_face = '!Bitstream Vera Sans Mono'
local font_size = 10
if WIN32 then
  font_face = '!Consolas'
elseif OSX then
  font_face = '!Monaco'
  font_size = 12
end
l.style_default = style {
  font = font_face,
  size = font_size,
  fore = l.colors.base00,
  back = l.colors.base3
}
l.style_line_number = style { fore = l.colors.base1, back = l.colors.base2 }
l.style_bracelight = style { fore = l.colors.base2, back = l.colors.green, bold = true }
l.style_bracebad = style { fore = l.colors.base2, back = l.colors.red, bold = true }
l.style_controlchar = l.style_nothing
l.style_indentguide = style { fore = l.colors.base2, back = l.colors.base3 }
l.style_calltip = style { fore = l.colors.base3, back = l.colors.base2 }
