-- Copyright 2007-2011 Mitchell mitchell<att>caladbolg.net. See LICENSE.
-- Dark editor theme for Textadept.

-- Modified by Brian Schott. Colors based on the Solarized theme by
-- Ethan Schoonover http://ethanschoonover.com/solarized

local buffer = buffer

-- Folding.
buffer.property['fold'] = '1'
buffer.property['fold.by.indentation'] = '1'
buffer.property['fold.line.comments'] = '`'

-- Tabs and Indentation.
buffer.tab_width = 4
buffer.use_tabs = false
buffer.indent = 4
buffer.tab_indents = true
buffer.back_space_un_indents = true
