return {
	[0x17000]="TANGUT IDEOGRAPH-*",
}