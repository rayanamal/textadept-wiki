local name_data_module_name = 'common.unicodename.data.%04X'

local function arg_error(funcname, arg, msg, level)
  error(('bad argument #%d to \'%s\' (%s)'):format(arg, funcname, msg),
    level and level + 1 or 2)
end

-- Roughly equivalent to luaL_checkinteger.
local function check_integer(val, funcname, arg)
  return math.tointeger(val)
    or arg_error(funcname, arg,
      type(tonumber(val)) == 'number' and 'number has no integer representation'
      or ('number expected, got %s'):format(type(val)), 2)
end
  

local name_data_mt = {}
local name_data = setmetatable({}, name_data_mt)
function name_data_mt:__index(key)
  key = check_integer(key, 'name_data_mt.__index', 2)
  if not (0 <= key and key <= 0x10FF) then
    arg_error(name_data_mt.__index, 2, 'value out of range')
  end
  local ok, group_data = pcall(require, name_data_module_name:format(key))
  if ok then
	  self[key] = group_data
	  return group_data
  end
end

function name_data_mt:__tostring()
  local keys = {}
  for k in pairs(self) do
    table.insert(keys, k)
  end
  if not keys[1] then return '{}' end
  table.sort(keys)
  
  local str = {}
  table.insert(str, '{')
  for _, key in pairs(keys) do
    table.insert(str, ('  0x%02X = { U+%02X00-U+%02XFF },'):format(key, key, key))
  end
  table.insert(str, '}')
  
  return table.concat(str, '\n')
end

-- From Module:Unicode_data and Module:Unicode_data/Hangul on English Wiktionary.
-- Data used to generate the names of characters in the Hangul Syllables block
-- (U+AC00 to U+D7A3).
local Hangul = {}

-- The following leads, vowels, and trails come from here:
-- http://www.unicode.org/Public/UNIDATA/Jamo.txt
Hangul.leads = {
	[0] = 'G', 'GG', 'N', 'D', 'DD', 'R', 'M', 'B', 'BB', 'S', 'SS',
	'', 'J', 'JJ', 'C', 'K', 'T', 'P', 'H'
}

Hangul.vowels = {
	[0] = 'A', 'AE', 'YA', 'YAE', 'EO', 'E', 'YEO', 'YE', 'O', 'WA',
	'WAE', 'OE', 'YO', 'U', 'WEO', 'WE', 'WI', 'YU', 'EU', 'YI',
	'I'
}
Hangul.vowel_count = #Hangul.vowels + 1

Hangul.trails = {
	[0] = '', 'G', 'GG', 'GS', 'N', 'NJ', 'NH', 'D', 'L', 'LG', 'LM', 'LB',
	'LS', 'LT', 'LP', 'LH', 'M', 'B', 'BS', 'S', 'SS', 'NG', 'J', 'C', 'K',
	'T', 'P', 'H'
}
Hangul.trail_count = #Hangul.trails + 1

Hangul.final_count = Hangul.vowel_count * Hangul.trail_count

local name_rules = {
  -- {     0x00,     0x1F, '<control-%04X>' }, -- C0 control characters
  -- {     0x7F,     0x9F, '<control-%04X>' }, -- DEL and C1 control characters
  {   0x3400,   0x4DB5, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension A
  {   0x4E00,   0x9FEF, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph
  {   0xAC00,   0xD7A3, function (codepoint) -- Hangul Syllables
    local syllable_index = codepoint - 0xAC00

    return ('HANGUL SYLLABLE %s%s%s'):format(
      Hangul.leads[syllable_index // Hangul.final_count],
      Hangul.vowels[(syllable_index % Hangul.final_count)
        // Hangul.trail_count],
      Hangul.trails[syllable_index % Hangul.trail_count]
    )
  end },
  -- High Surrogates, High Private Use Surrogates, Low Surrogates
  {   0xD800,   0xDFFF, '<surrogate-%04X>' },
  {   0xE000,   0xF8FF, '<private-use-%04X>' }, -- Private Use
  -- CJK Compatibility Ideographs
  {   0xF900,   0xFA6D, 'CJK COMPATIBILITY IDEOGRAPH-%04X' },
  {   0xFA70,   0xFAD9, 'CJK COMPATIBILITY IDEOGRAPH-%04X' },
  {  0x17000,  0x187F1, 'TANGUT IDEOGRAPH-%04X' }, -- Tangut
  {  0x18800,  0x18AF2, function (codepoint)
    return ('TANGUT COMPONENT-%03d'):format(codepoint - 0x18800 + 1)
  end },
  {  0x1B170,  0x1B2FB, 'NUSHU CHARACTER-%04X' }, -- Nushu
  {  0x20000,  0x2A6D6, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension B
  {  0x2A700,  0x2B734, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension C
  {  0x2A740,  0x2B81D, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension D
  {  0x2B820,  0x2CEA1, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension E
  {  0x2CEB0,  0x2EBE0, 'CJK UNIFIED IDEOGRAPH-%04X' }, -- CJK Ideograph Extension F
  -- CJK Compatibility Ideographs Supplement (Supplementary Ideographic Plane)
  {  0x2F800,  0x2FA1D, 'CJK COMPATIBILITY IDEOGRAPH-%04X' },
  {  0xE0100,  0xE01EF, function (codepoint) -- Variation Selectors Supplement
    return ('VARIATION SELECTOR-%d'):format(codepoint - 0xE0100 + 17)
  end},
  {  0xF0000,  0xFFFFD, '<private-use-%04X>' }, -- Plane 15 Private Use
  { 0x100000, 0x10FFFD, '<private-use-%04X>' }  -- Plane 16 Private Use
}

local function generate_name_from_rule(rule, codepoint)
  if type(rule) == 'string' then
    return rule:format(codepoint)
  else
    return rule(codepoint)
  end
end

local function get_name(codepoint)
  if 0xFDD0 <= codepoint and (codepoint <= 0xFDEF
			or codepoint & 0xFFFE == 0xFFFE) then
		return ('<noncharacter-%04X>'):format(codepoint)
	end
  
  for _, rule in ipairs(name_rules) do
    if codepoint < rule[1] then
      break
    elseif codepoint <= rule[2] then
      return generate_name_from_rule(rule[3], codepoint)
    end
  end
  
  local group_data = name_data[codepoint // 0x100]
  return group_data and group_data[codepoint] or ('<reserved-%04X>'):format(codepoint)
end

local function unicodename(...)
  local res = {}
  for i = 1, select('#', ...) do
    local codepoint = select(i, ...)
    codepoint = check_integer(codepoint, 'unicodename', i)
    if not (0 <= codepoint and codepoint <= 0x10FFFF) then
      arg_error('unicodename', i, 'out of range')
    end
    table.insert(res, get_name(codepoint))
  end
  return table.unpack(res)
end

return unicodename