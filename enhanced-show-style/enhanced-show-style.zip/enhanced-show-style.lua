local M = {}

_G.unicodename = require 'common.unicodename'

local endianness_suffix = string.pack('=H', 1) == string.pack('<H', 1) and 'LE' or 'BE'

local get_bytes_per_code_unit, is_UTF8
do
  local _ENV, tonumber = lpeg, tonumber
  local function case_insensitive_P(str)
    local patt = P ''
    for char in str:gmatch '.' do
      patt = patt * (P(char:lower()) + P(char:upper()))
    end
    return patt
  end
  local Pi = case_insensitive_P
  local patt = ((Pi 'UTF' * P  '-'^-1 * (P '16' / 2 + P '32' / 4)
             +   Pi 'UCS' * P  '-'^-1 * (P '2'  / 2 + P '4' / 4))
             * ((Pi 'B'   + Pi 'L')   *  Pi 'E')^-1 * P(-1))
  function get_bytes_per_code_unit(encoding)
    return patt:match(encoding)
  end
end

-- Convert UTF-8 in buffer to actual encoding in file and show the resulting bytes.
-- Show the name of the codepoint if possible using the unicodename function.
function M.new_show_style()
  if buffer.current_pos == buffer.length then return end -- end of buffer
  local char = buffer:text_range(buffer.current_pos,
                   buffer:position_after(buffer.current_pos))
  local valid_UTF8, codepoint1, codepoint2 = pcall(utf8.codepoint, char, 1, -1) -- for CRLF
  local actual_char = char
  local encoding = buffer.encoding
  local byte_format
  if M.show_saved_bytes and encoding and not encoding:upper():find '^UTF%-?8$' then
    -- Show actual bytes in saved file.
    local bytes_per_code_unit = get_bytes_per_code_unit(encoding)
    -- If encoding is UTF-16 or UTF-32 or UCS-2 or UCS-4,
    -- add byte-order suffix so that iconv does not add a byte-order mark
    -- at the beginning of the converted string.
    if bytes_per_code_unit and not encoding:upper():find('[LB]E$') then
      encoding = encoding .. endianness_suffix
    end
    local ok
    ok, actual_char = pcall(string.iconv, char, encoding, 'UTF-8')
    if ok then
      if bytes_per_code_unit then
        byte_format = ('0x' .. ('%02X'):rep(bytes_per_code_unit)):rep(#actual_char / bytes_per_code_unit, ' ')
      end
    else
      -- Conversion failed (character cannot appear in encoding used by
      -- saved version of file); just show UTF-8 encoding of character.
      -- This is inconsistent, unfortunately!
      actual_char = char
    end
  end
  byte_format = byte_format or ('0x%02X'):rep(#actual_char, ' ')
  local bytes = byte_format:format(actual_char:byte(1, -1))
  local style = buffer.style_at[buffer.current_pos]
  local char_desc
  if valid_UTF8 then
    local codepoints = ('U+%04X'):format(codepoint1)
    if codepoint2 then
      codepoints = codepoints .. (' U+%04X'):format(codepoint2)
    end
    char_desc = ("'%s' (%s: %s)"):format(char, codepoints, bytes)
    if M.show_codepoint_names and _G.unicodename then
      char_desc = char_desc .. '\n' .. table.concat({
        _G.unicodename(codepoint1), codepoint2 and _G.unicodename(codepoint2)
      }, ' ')
    end
  else
    char_desc = bytes
  end
  local text = string.format('%s\n%s %s\n%s %s (%d)',
							 char_desc,
							 _L['Lexer'], buffer:get_lexer(true),
							 _L['Style'], buffer.style_name[style], style)
  buffer:call_tip_show(buffer.current_pos, text)
end

textadept.menu.menubar[_L['_Tools']][_L['Show St_yle']][2] = M.new_show_style
keys[not OSX and (not CURSES and 'ci' or 'mI') or 'mi'] = M.new_show_style

return M