-- Copyright (c) 2018 George Hawkins

-- See file "LICENSE" in this folder

--[[
------------------------------------------------------------
                  =======================
                  ====  DESCRIPTION  ====
                  =======================

  This module formats the paragraph containing the cursor.

  The paragraph containing the cursor determines the initial
  paragraph line indent and the second line of the paragraph
  determines the indentation for the remainder of the
  paragraph.

  The paragraph is "wrapped" based on the value of
  "buffer.edge_column". If buffer.edge_column is 0, then a
  default value of "80" is used. (NOTE: this may be changed
  by modifying the code line:

    wrapCol = 80 -- default wrap col

  if desired)

  At the end of formatting the cursor is positioned at the
  next paragraph. Therefore, multiple presses of the
  (assigned to) QuickFormat key will continue to format
  paragraphs sequentially.

  The formatting is intended to be used on lexical (as
  opposed to program language) files. Anything other than a
  Space, Horizontal Tab, Line Feed, or Carriage Return
  character is treated as a word character. Non-word
  characters are eliminated and replaced with single spaces
  or end-of-line characters as appropriate.

  SPECIAL NOTE: textadept always adds a terminating LF when
  saving a buffer, consequently this module expects this to
  be the case. If you invoke this module while appending to
  the active buffer without first saving the file then the
  terminal paragraph will not be formatted.

------------------------------------------------------------
--]]


------------------------------------------------------------

local M = {}

function M.QuickFormat()

  --[[
  ----------------------------------------------------------
                  ======================
                  ====  LOCAL DATA  ====
                  ======================

              data used locally in the module
  ----------------------------------------------------------
  --]]

  local paragraph2Format  -- selected paragraph to format
  -- selected paragraph characteristics
  local selLine1Indent, selLine2Indent
  -- other data
  local orig_indent_Flag      -- initial auto_indent mode
  local trailingLFs           -- trailing LF's in selection
  -- constants
  local SP = 32   -- space byte           == break token
  local CR = 13   -- carriage return byte == break token
  local LF = 10   -- linefeed byte        == break token
  local HT = 09   -- horizontal tab byte  == break token

  --[[
  ----------------------------------------------------------
                  =======================
                  ====  LOCAL PROCS  ====
                  =======================

            reserved for all local procedures
  ----------------------------------------------------------
  --]]

  -- inform user of fatal error encountered
  local FatalError = function(msgOut)
    local mode = ui.dialogs.msgbox{
      title = '**** ERROR ****', text = msgOut,
      icon = 'gtk-dialog-error',
      button1 = 'ABORT'
    }
  end

  -- determine number of trailing paragraph line feeds
  local GetTrailingLFs = function(inputParagraph)
    local testByte, numTermLF
    numTermLF = 0
    for i = string.len(inputParagraph), 1, -1 do
      testByte = string.byte(inputParagraph, i)
      if testByte == LF then
        -- increment if LF
        numTermLF = numTermLF + 1
      elseif  testByte ~= SP
          and
              testByte ~= CR
          and
              testByte ~= HT
          then
        -- break if "word char"
        break
      end
    end
    return numTermLF
  end

  -- formats a paragraph of text
  local FormatOneParagraph = function(
        inputParagraph,
        firstLineIndent,
        bodyIndent,
        wrapCol
      )

    -- INTERNAL DATA

    --[[
      constants below are commented out since they are
      upvalues; may wish to uncomment if FormatOneParagraph
      is used externally
    -- constants
    local SP = 32   -- space byte           == break token
    local CR = 13   -- carriage return byte == break token
    local LF = 10   -- linefeed byte        == break token
    local HT = 09   -- horizontal tab byte  == break token
    --]]

    -- booleans
    local moreInput_Flag
    local inWord_Flag, firstWordInLine_Flag
    -- arrays
    local outputArray
    -- state information
    local inputParaPos, inputParaLength, currByte
    local currLinePos, currLineIndent
    local currWordBegPos, currWordLength
    -- strings
    local outputParagraph

    -- INITIALIZE DATA
    inputParaPos =  0
    inputParaLength = string.len(inputParagraph)
    outputArray = {}

    -- INTERNAL PROCEDURES

    -------------- Line construction functions

    -- indent current line
    local AddIndent= function()
      if currLineIndent > 0 then
        for i = 1, currLineIndent do
          table.insert(outputArray, SP)
        end
        currLinePos = currLinePos + currLineIndent
      end
    end

    -- add the word token
    local AddWordToken = function()
      for i = 1, currWordLength do
        table.insert(
          outputArray,
          string.byte(inputParagraph, currWordBegPos+i-1)
        )
      end
      currLinePos = currLinePos + currWordLength
    end

    -- add EOL based on  buffer.eol_mode
    local AddEOL = function()
      if buffer.eol_mode == buffer_EOL_CRLF then
        -- add CR if windoze
        table.insert(outputArray, CR)
      end
      -- add LF
      table.insert(outputArray, LF)
      currLinePos = 1
      currLineIndent = bodyIndent
    end

    -- add word to current line
    local AddWord = function()
      if firstWordInLine_Flag then
        -- first word in line - force insert
        AddIndent()
        AddWordToken()
        firstWordInLine_Flag = false
      else
        -- not first word in line
        if currLinePos + currWordLength > wrapCol then
          -- not enough space - add to next line
          AddEOL()
          AddIndent()
          AddWordToken()
        else
          -- got room - add with preceeding space
          table.insert(outputArray, SP)
          currLinePos = currLinePos + 1
          AddWordToken()
        end
      end
    end

    -------------- search functions

    -- locate next word byte if any
    --    returns position of next word
    --    byte or false if end of inputParagraph
    local FindNextWordByte = function()
    ::GET_NEXT_BYTE::
      inputParaPos = inputParaPos + 1
      if inputParaPos > inputParaLength then
        return false
      else
        currByte = string.byte(inputParagraph, inputParaPos)
        if  currByte ~= SP
            and
            currByte ~= LF
            and
            currByte ~= CR
            and
            currByte ~= HT
            then
          return inputParaPos
        else
          goto GET_NEXT_BYTE
        end
      end
    end

    -- locate next break byte if any
    --    returns position of next break
    --    byte or false if end of inputParagraph
    local FindNextBreakByte = function()
    ::GET_NEXT_BYTE::
      inputParaPos = inputParaPos + 1
      if inputParaPos > inputParaLength then
        return false
      else
        currByte = string.byte(inputParagraph, inputParaPos)
        if  currByte == SP
            or
            currByte == LF
            or
            currByte == CR
            or
            currByte == HT
            then
          return inputParaPos
        else
          goto GET_NEXT_BYTE
        end
      end
    end


    --------------------------------------------------
    -------------- BEGIN MAIN FUNCTION ---------------
    --------------------------------------------------

    -- loop variables
    moreInput_Flag = true         -- must have at least one input byte
    inWord_Flag = false           -- start out looking for a word
    firstWordInLine_Flag = true   -- true if adding the first word in
                                  -- a line (i.e.: no preceeding SP)
    currLinePos = 1
    currLineIndent = firstLineIndent

    -- main search loop
    ::GET_NEXT_TOKEN::
      if inWord_Flag then
        -- found a word - look for break
        moreInput_Flag = FindNextBreakByte()
        if moreInput_Flag then
          -- got beginning of break
          inWord_Flag = false
          currWordLength = inputParaPos - currWordBegPos
          -- transfer word from inputParagraph to outputArray
          AddWord()
          goto GET_NEXT_TOKEN
        else
          -- paragraph exhausted
          goto END_OF_PARAGRAPH
        end
      else
        -- in a break, look for word
        moreInput_Flag = FindNextWordByte()
        if moreInput_Flag then
          -- got beginning of a word
          inWord_Flag = true
          currWordBegPos = inputParaPos
          goto GET_NEXT_TOKEN
        else
          -- paragraph exhausted
          goto END_OF_PARAGRAPH
        end
      end

    ::END_OF_PARAGRAPH::

    -- convert & concatenate formatted outputArray
    for i = 1, #outputArray do
      outputArray[i] = string.char(outputArray[i])
    end
    outputParagraph = table.concat(outputArray)

    return outputParagraph

  end


  --[[
  ----------------------------------------------------------
                    ======================
                    ====  BEGIN MAIN  ====
                    ======================
  ----------------------------------------------------------
  --]]

  -- ensure no selection currently made
  if not buffer.selection_empty then
    FatalError([=[
      NO SELECTION ALLOWED
       DESELECT AND RERUN
    ]=])
    goto NOTHING_DONE
  end

  -- undo/redo start
	buffer:begin_undo_action()

  -- save original auto_indent for later restore
  orig_indent_Flag = textadept.editing.auto_indent
  textadept.editing.auto_indent = false

  -- select current paragraph and format
  textadept.editing.select_paragraph()

  -- paragraph must end with at least 1 LF
  if buffer.char_at[buffer.selection_end-1] ~= LF then
    buffer:end_undo_action()
    textadept.editing.auto_indent = orig_indent_Flag
    FatalError([=[
      PARAGRAPH NOT PROPERLY TERMINATED
          SAVE FILE AND RERUN
    ]=]
    )
    goto NOTHING_DONE
  end

  paragraph2Format = buffer:get_sel_text()

  selLine1Indent = buffer.line_indentation[
      buffer:line_from_position(buffer.selection_start)
    ]

  selLine2Indent = buffer.line_indentation[
      (buffer:line_from_position(buffer.selection_start)+1)
    ]

  if buffer.edge_column > 0 then
    wrapCol = buffer.edge_column
  else
    wrapCol = 80  -- default wrap col
  end

  trailingLFs = GetTrailingLFs(paragraph2Format)

  buffer:replace_sel(FormatOneParagraph(
    paragraph2Format,
    selLine1Indent,
    selLine2Indent,
    wrapCol
    )
  )

  -- add trailing LF's ~~
  for i = 1, trailingLFs do
    buffer:new_line()
  end

  -- undo/redo end
	buffer:end_undo_action()

  -- restore original auto_indent
	textadept.editing.auto_indent = orig_indent_Flag

::NOTHING_DONE::

end

return M
