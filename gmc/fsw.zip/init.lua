-- Copyright (c) 2018 George Hawkins

-- See file "LICENSE" in this folder

--[[
------------------------------------------------------------
                  =======================
                  ====  DESCRIPTION  ====
                  =======================

This module provides a quick word/string search capability.

The word to be located may be set/specified in a number of
ways.

If you have made a simple selection, then this will take
priority (function FindWord). The selection will be matched
in regard to case but will not require a whole word match
(i.e.: the string will be matched within a word).

Alternatively, you may specify a word as an argument to the
FindWord function. If you specify a second, optional
argument, then this will be used as the search word. The
search will be a case sensitive search for a whole word.

This optional second argument allows you to effectively set
permanent bookmarks in textadept.

Finally, if neither of the above apply, you must first "set"
the word to be located (function SetWord). Invoking the
SetWord function determines if there is a word at the
current cursor position and, if so, it sets this as the word
to be located. If there is no word at the cursor position,
then the user is requested to move the cursor to the word
desired.

Once a word has been set, then function FindWord will locate
the next or prior instance of the word. The search is a case
sensitive search for a whole word

The first argument to FindWord determines whether the search
is for the next or the prior word. If "false", then the next
instance of the word is located. If "true", then the prior
instance of the word is located.

So, for example, if FindWord is called with no arguments
(and no selection) then it will attempt to search for the
next occurrence of the "set" word. If it is called with
arguments "true" and "23+Sam", it will search for a prior
occurrence of the word "23+Sam". If it is called with the
string "Abc" selected and no arguments, then it will search
for the next occurrence of "Abc" within a word.

If the word is not located, then FindWord "wraps" to the
beginning or end of the buffer as appropriate to continue
the search.

FindWord keeps the user informed of the search word and
status via the status bar.

Once a word/string has been defined via a selection, via the
SetWord function, or via the 2nd argument, it is "sticky".
That is, it will be remembered for subsequent searches. The
nature of the search in regard to either whole word (SetWord
or 2nd argument) or within word (simple selection) is sticky
as well.

The term "word" herein means any sequence of ASCII
characters between 33 and 126. The textadept
buffer:word_start_position and buffer:word_end_position look
for (effectively) a standard programming language word. This
may not be desired, particular in regard to lexical
compositions. Hence the definition of word above. However,
if textadept's definition of word is desired, then the
function may be easily modified to do so. Comments are
included in FindWord to allow this.

Another difference between textadept's buffer:word start/end
position functions and FindWord is that textadept will
"find" the start/end of a word even if the cursor is one
position past the end of the word. This function will not.

------------------------------------------------------------
--]]

local M = {}

-- UPVALUES
local flags, wordFound, initPos, b, e
wordFound = ''  -- must set 1st time

-- FUNCTIONS

-- determines if char at cursor is a word character
-- "word" is any sequence of ASCII
-- values between 33 and 126
local IsWordChar = function(pos)
  local MINBYTE, MAXBYTE = 33, 126
  local testByte
  testByte = buffer.char_at[pos]
  return  ( testByte>=MINBYTE
              and
            testByte<=MAXBYTE
              and
            true
          )
            or
          false
end

-- determines if there is a "word" at the cursor
local Word_at_Cursor = function()
  local initBuffPos, currBuffPos, homePos

  initBuffPos = buffer.current_pos
  currBuffPos = initBuffPos

  -- assume word not found
  b, e = initBuffPos, initBuffPos

  -- if not in a word return immediately
  if not IsWordChar(initBuffPos) then return end
  -- we're in a word
  buffer:home()
  homePos = buffer.current_pos
  if  initBuffPos == homePos
        or
      not IsWordChar(initBuffPos-1)
      -- at beginning of line or beginning of word
      -- "b" value o.k.
  then
    goto FIND_WORD_END
  end
  -- find beginning of word
  while IsWordChar(currBuffPos)
          and
        currBuffPos >= homePos
  do
    currBuffPos = currBuffPos - 1
  end
  -- not word char or at homePos
  if not IsWordChar(currBuffPos) then
    b = currBuffPos + 1
  else
    b = homePos
  end
  currBuffPos = initBuffPos
::FIND_WORD_END::
  while IsWordChar(currBuffPos) do
    currBuffPos = currBuffPos + 1
  end
  e = currBuffPos
  -- restore cursor position
  buffer:goto_pos(initBuffPos)
  --[[
                           NOTE:

    If you want to use textadept's definition of a word,
    then you may delete everything in this function after
    the line "initBuffPos = buffer.current_pos" and include
    the two lines below. Additionally, function IsWordChar
    will not be needed.

  --]]
  --b = buffer:word_start_position(initPos, true)
  --e = buffer:word_end_position(initPos, true)
end

function M.SetWord()
  Word_at_Cursor()
  if b == e then
    -- no word found
    local mode = ui.dialogs.msgbox{
      title = '---- CURSOR NOT ON WORD ----',
      text = 'CURSOR MUST BE AT A WORD',
      icon = 'gtk-dialog-info',
      button1 = 'CONTINUE'
    }
  else
    wordFound  = buffer:text_range(b, e)
    flags =
      buffer.FIND_MATCHCASE
      + buffer.FIND_WHOLEWORD
    ui.statusbar_text =
      '**** SEARCH WORD SET TO:  '..wordFound..' ****'

  end
end

function M.FindWord(prior, inWord)

  local adjWordPos

  initPos = buffer.current_pos

  -- check for simple selection
  -- overrides selection at cursor or 2nd argument
  if  (not buffer.selection_empty)
        and
      (not buffer.selection_is_rectangle)
  then
    wordFound = buffer:text_range(
                  buffer.selection_start,
                  buffer.selection_end
                )
    b = buffer.selection_start
    e = buffer.selection_end
    buffer:set_empty_selection(initPos)
    flags = buffer.FIND_MATCHCASE
    goto FIND_WORD
  end

  -- input word?
  if inWord then
    -- prevent self match
    b = initPos
    e = initPos + 1
    wordFound = inWord
    flags =
      buffer.FIND_MATCHCASE
      + buffer.FIND_WHOLEWORD
  else
    -- have we set a search word?
    if wordFound == '' then
      local mode = ui.dialogs.msgbox{
        title = '---- NO SEARCH WORD SET ----',
        text = 'You must first set a word for the search.',
        icon = 'gtk-dialog-info',
        button1 = 'CONTINUE'
      }
      return
    else
      b = initPos
      e = initPos + string.len(wordFound)
    end
  end

::FIND_WORD::
  for i = 1, 2 do
    -- look for adjacent word
    if prior then
      -- prior word
      if i == 1 then
        buffer:goto_pos(b)
      else
        buffer:document_end()
      end
      buffer:search_anchor()
      adjWordPos = buffer:search_prev(flags, wordFound)
      if adjWordPos == -1 then
        ui.statusbar_text =
          '**** CANNOT FIND:  '..wordFound..' ****'
      else
        ui.statusbar_text =
          '**** PRIOR INSTANCE OF:  '..wordFound..' ****'
      end
    else
      -- next word
      if i == 1 then
        buffer:goto_pos(e)
      else
        buffer:document_start()
      end
      buffer:search_anchor()
      adjWordPos = buffer:search_next(flags, wordFound)
      if adjWordPos == -1 then
        ui.statusbar_text =
          '**** CANNOT FIND:  '..wordFound..' ****'
      else
        ui.statusbar_text =
          '**** NEXT INSTANCE OF:  '..wordFound..' ****'
      end
    end
    -- word found?
    if adjWordPos ~= -1 then
      buffer:goto_pos(adjWordPos)
      buffer:vertical_centre_caret()
      break
    end
  end
end

return M
