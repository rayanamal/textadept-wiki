-- Copyright (c) 2018 George Hawkins

-- See file "LICENSE" in this folder

--[[
-----------------------------------------------------------
                  =======================
                  ====  DESCRIPTION  ====
                  =======================

  This module centers the current line of text.

-----------------------------------------------------------
--]]

-----------------------------------------------------------

local M = {}

function M.CenterLine()

  --[[
  -----------------------------------------------------------
                  ======================
                  ====  LOCAL DATA  ====
                  ======================
  -----------------------------------------------------------
  --]]

  --constants
  local SP = 32   -- space byte           == break token
  local CR = 13   -- carriage return byte == break token
  local LF = 10   -- linefeed byte        == break token
  local HT = 09   -- horizontal tab byte  == break token

  local DEFAULTLINELENGTH = 80

  -- variables
  local line2Center, inputLineLength
  local currPos, currByte
  local firstWordByte, lastWordByte
  local outputLine, lineLength, indent


  --[[
-----------------------------------------------------------
                  =======================
                  ====  LOCAL PROCS  ====
                  =======================
-----------------------------------------------------------
  --]]

  -- inform user of fatal error encountered
  local FatalError = function(msgOut)
    local mode = ui.dialogs.msgbox{
      title = '**** ERROR ****', text = msgOut,
      icon = 'gtk-dialog-error',
      button1 = 'ABORT'
    }
  end

  local IsWordByte = function()
    -- returns true if current byte
    -- is a word byte
    if  currByte == SP
      or
      currByte == LF
      or
      currByte == CR
      or
      currByte == HT
    then
      --PauseTest('false ')
      return false
    else
      --PauseTest('true ')
      return true
    end
  end

  --[[
-----------------------------------------------------------
                   ======================
                   ====  BEGIN MAIN  ====
                   ======================
-----------------------------------------------------------
  --]]

  -- ensure no selection currently made
  if not buffer.selection_empty then
    FatalError([=[
      NO SELECTION ALLOWED
       DESELECT AND RERUN
    ]=])
    return
  end

  firstWordByte = false -- not really needed
  textadept.editing.select_line()
  line2Center = buffer:get_sel_text()
  inputLineLength = string.len(line2Center)
  if inputLineLength < 1 then goto ALL_DONE end

  buffer:begin_undo_action()
  currPos = 1
  while currPos <= inputLineLength do
    currByte = string.byte(line2Center, currPos)
    if IsWordByte() then
      if not firstWordByte then
        firstWordByte = currPos
      end
      lastWordByte = currPos
    end
    currPos = currPos + 1
  end
  outputLine = string.sub(
                  line2Center,
                  firstWordByte,
                  lastWordByte
                )
  if buffer.edge_column then
    lineLength = math.min(
                            buffer.edge_column,
                            DEFAULTLINELENGTH
                        )
  else
    lineLength = DEFAULTLINELENGTH
  end
  indent = math.floor(
    (lineLength - (lastWordByte - firstWordByte + 1)) /2
    )
  buffer:replace_sel(outputLine)
  buffer.line_indentation[      -- center by indenting
      buffer:line_from_position(buffer.current_pos)
  ] = indent
  buffer:end_undo_action()

::ALL_DONE::
  buffer:line_down()            -- ready for next line

end

return M
