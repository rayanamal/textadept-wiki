-- Copyright (c) 2018 George Hawkins

-- See file "LICENSE" in this folder

--[[
                  =======================
                  ====  DESCRIPTION  ====
                  =======================

  See file "README" in this folder for summary
  documentation.

  See file "TARP_DOC.txt" in this folder for full
  documentation (recommended reading if you want to use this
  module at other than a base level).

--]]

------------------------------------------------------------

local M = {}

--[[
          =======================================
          ====            UPVALUES           ====
          =======================================
--]]

-- allows self/global reference for disconnect
local KeyPressAction

-- stops attempted replay while recording
local recordingMacro_Flag = false

-- KEYPRESS event values
local code, shift, control, alt, meta, capsLock

-- derived KEYPRESS event values
local keyModifiers, keySymbol, keySequence

local userHome = _USERHOME
local macrosHome =  userHome
  ..( (WIN32 and '\\') or '/')
  ..'macros'


              -------------------------------
              -----        CKA's        -----
              ----    plus functions     ----
              ----    needed by CKA's    ----
              -------------------------------

-- the currently active macro (CKA)
local RKeys = {}

-- dummy function used to test out new CKA assignments
local NYA = function()
  local mode = ui.dialogs.msgbox{
    title = '**** INFORMATION ****',
    text = '---- KEY NOT YET ASSIGNED ----',
    icon = 'gtk-dialog-info',
    button1 = 'CONTINUE'
  }
end
-- END NYA

-- insert text in buffer
-- "bat" == buffer add text
local bat = function(text2add)
  -- handle overtype mode
  local cbpos, lepos
  cbpos = buffer.current_pos
  buffer:line_end()
  lepos = buffer.current_pos
  buffer:goto_pos(cbpos)
  if buffer.overtype
      and
    (string.len(text2add)==1)
      and
    (cbpos~=lepos)
  then
    buffer:char_right()
    buffer:delete_back()
  end
  buffer:add_text(text2add)
end
-- END bat

-- tab function
-- "bt" == buffer tab
local bt = function()
  buffer:tab()
end
-- END bt

-- back tab function
-- "bbt" == buffer back tab
local bbt = function()
  buffer:back_tab()
end
-- END bbt

-- autopair brackets function
local apbr = function(code, run)
  local bEnd
  if      code == 40 then bEnd =  41    --  ()
  elseif  code == 91 then bEnd =  93    --  []
  elseif  code == 123 then bEnd = 125   --  {}
  elseif  code == 34 then bEnd =  34    --  ""
  elseif  code == 39 then bEnd =  39    --  ''
  else                    bEnd =  0  end

  if bEnd > 0 then
    if run then
      bat(string.char(code)..string.char(bEnd))
      buffer:char_left()
    end
    return true
  else
    return false
  end
end
-- END apbr

-- keys in _HOME/core/keys.lua  (CKA)
-- i.e.: KEYSYMS table
local keysymsActions = {
  ['esc']     = NYA,   -- currently a _G.keys function
  ['\n']      = buffer.new_line,
  ['\b']      = buffer.delete_back,
  ['down']    = buffer.line_down,
  ['up']      = buffer.line_up,
  ['left']    = buffer.char_left,
  ['right']   = buffer.char_right,
  ['home']    = buffer.home,
  ['end']     = buffer.line_end,
  ['pgup']    = buffer.page_up,
  ['pgdn']    = buffer.page_down,
  ['del']     = NYA,   -- currently a _G.keys function
  ['ins']     = buffer.edit_toggle_overtype,
  ['\t']      = bt,    -- force _G.keys exclusion
  ['kpenter'] = buffer.new_line,
  ['kphome']  = buffer.home,
  ['kpend']   = buffer.line_end,
  ['kpleft']  = buffer.char_left,
  ['kpup']    = buffer.line_up,
  ['kpright'] = buffer.char_right,
  ['kpdown']  = buffer.line_down,
  ['kppgup']  = buffer.page_up,
  ['kppgdn']  = buffer.page_down,
  ['kpmul']   = { bat, '*' },
  ['kpadd']   = { bat, '+' },
  ['kpsub']   = { bat, '-' },
  ['kpdiv']   = { bat, '/' },
  ['kpdec']   = { bat, '.' },
  ['kp0']     = { bat, '0' },
  ['kp1']     = { bat, '1' },
  ['kp2']     = { bat, '2' },
  ['kp3']     = { bat, '3' },
  ['kp4']     = { bat, '4' },
  ['kp5']     = { bat, '5' },
  ['kp6']     = { bat, '6' },
  ['kp7']     = { bat, '7' },
  ['kp8']     = { bat, '8' },
  ['kp9']     = { bat, '9' },

  --[[
    Nothing needed for the "f" keys since, if they are
    unassigned they will "fall through" all of TARP's
    tests and result in an error prompt. At which point
    the user can press the CONTINUE button.
  ['f1']      = NYA,
  ['f2']      = NYA,
  ['f3']      = NYA,
  ['f4']      = NYA,
  ['f5']      = NYA,
  ['f6']      = NYA,
  ['f7']      = NYA,
  ['f8']      = NYA,
  ['f9']      = NYA,
  ['f10']     = NYA,
  ['f11']     = NYA,
  ['f12']     = NYA,
  --]]
}
-- END keysymsActions

--[[

 most of the keys in _HOME/modules/textadept/keys.lua are
 assigned as functions in _G.keys; those that are not, we
 try to account for here; the _G.keys assignments are
 included here as placeholders/comments in case we wish to
 redefine them at some later point

 As of this writing we have:

 112 _G.keys assignments processed by GkeyEvent
   4 _G.keys are specifically prohibited
  35    keys are documented but unassigned and are
        accounted for here

 NOTE: this CKA is examined AFTER we look for _G.keys
  assignments; so all of these commented out keys will have
  already been assigned

--]]
local otherKeyActions = {
            ------------------------------------
            --------        FILE        --------
            ------------------------------------
  --['cn']        = { io.open_file, 'Untitled' },
  --['co']        = io.open_file,
  --[cao]         = io.open_recent_file,
  --['cO']        = io.reload_file,
  --['cs']        = io.save_file,
  --['cS']        = io.save_file_as,
  --['cw']        = io.close_buffer,
  --['cW']        = io.close_all_buffers,
  -- NOTE: Quit, 'cq' is prohibited
  --['cq']        = quit,
            ------------------------------------
            --------        EDIT        --------
            ------------------------------------
  --['cz']        =  buffer.undo,
  ['a\b']         =  buffer.undo,
  --['cy']        = buffer.redo,
  --['cZ']        = buffer.redo,
  --['cx']        = buffer.cut,
  ['sdel']        = buffer.cut,
  --['cc']        = buffer.copy,
  ['cins']        = buffer.copy,
  --['cv']        = buffer.paste,
  ['sins']        = buffer.paste,
  --['cd']        = buffer.line_duplicate,
  --[[
   ['del']        =
                    {
                      -- strangely, there is no
                      -- "buffer.delete_forward"
                      -- i.e.: 'del' action
                      buffer.char_right,
                      buffer.delete_back
                    },
  --]]
  --[[
  ['adel']      =
                  {
                    buffer.char_right,
                    buffer.word_left,
                    buffer.del_word_right
                  },

  --]]
  --['ca']        = NYA,
  --['cm']        = NYA,
  --['c\n']       = NYA,
  --['caH']       = NYA,
  --['c/']        = NYA,
  --['ct']        = NYA,
  --['cJ']        = NYA,
  -- NOTE: Filter text through, 'c|' is prohibited
  --['c|']        = NYA,
  --['cM']        = NYA,
  --['c<']        = NYA,
  --['c>']        = NYA,
  --['cD']        = NYA,
  --['cN']        = NYA,
  --['cP']        = NYA,
  --['cau']       = NYA,
  --['caU']       = NYA,
  --['a<']        = NYA,
  --['a>']        = NYA,
  --['a"']        = NYA,
  --['a\'']       = NYA,
  --['a(']        = NYA,
  --['a[']        = NYA,
  --['a{']        = NYA,
  --['csup']      = NYA,
  --['csdown']    = NYA,
            ------------------------------------
            --------       SEARCH       --------
            ------------------------------------
  --['cf']        = NYA,
  --['cg']        = NYA,
  --['f3']        = NYA,
  --['cG']        = NYA,
  --['sf3']       = NYA,
  --['car']       = NYA,
  --['caR']       = NYA,
  -- NOTE: Find incremental, 'caf' is prohibited
  --['caf']       = NYA,
  --['cF']        = NYA,
  --['cag']       = NYA,
  --['caG']       = NYA,
  --['cj']        = NYA,
            ------------------------------------
            --------        TOOLS       --------
            ------------------------------------
  -- NOTE: Command entry, 'ce' is prohibited
  --['ce']        = NYA,
  --['cE']        = NYA,
  --['cr']        = NYA,
  --['cR']        = NYA,
  --['cA']        = NYA,
  --['cB']        = NYA,
  --['cX']        = NYA,
  --['cae']       = NYA,
  --['caE']       = NYA,
  --['c ']        = NYA,
  --['ch']        = NYA,
  --['ck']        = NYA,
  --['cf2']       = NYA,
  --['csf2']      = NYA,
  --['f2']        = NYA,
  --['sf2']       = NYA,
  --['af2']       = NYA,
  --['cu']        = NYA,
  --['caO']       = NYA,
  --['caP']       = NYA,
  --['ci']        = NYA,
            ------------------------------------
            --------       BUFFER       --------
            ------------------------------------
  --['c\t']       = NYA,
  --['cs\t']      = NYA,
  --['cb']        = NYA,
  --['caT']       = NYA,
  --['cai']       = NYA,
  --['ca\n']      = NYA,
  --['ca\\']      = NYA,
  --['caS']       = NYA,
  --['cL']        = NYA,
  --['f5']        = NYA,
            ------------------------------------
            --------        VIEW        --------
            ------------------------------------
  --['can']       = NYA,
  --['cap']       = NYA,
  --['cas']       = NYA,
  --['cah']       = NYA,
  --['cav']       = NYA,
  --['caw']       = NYA,
  --['caW']       = NYA,
  --['ca+']       = NYA,
  --['ca=']       = NYA,
  --['ca-']       = NYA,
  --['c*']        = NYA,
  --['caI']       = NYA,
  --['caV']       = NYA,
  --['c=']        = NYA,
  --['c-']        = NYA,
  --['c0']        = NYA,
  ------------------------------------
  --------        HELP        --------
  ------------------------------------
  --['f1']        = NYA,
  --['sf1']       = NYA,
  ------------------------------------
  --------      MOVEMENT      --------
  ------------------------------------
  --['down']      = buffer.line_down,   -- KEYSYMS
  ['sdown']       = buffer.line_down_extend,
  ['cdown']       = buffer.line_scroll_down,
  ['asdown']      = buffer.line_down_rect_extend,
  --['up']        = buffer.line_up,     -- KEYSYMS
  ['sup']         = buffer.line_up_extend,
  ['cup']         = buffer.line_scroll_up,
  ['asup']        = buffer.line_up_rect_extend,
  --['left']      = buffer.char_left,   -- KEYSYMS
  ['sleft']       = buffer.char_left_extend,
  ['cleft']       = buffer.word_left,
  ['csleft']      = buffer.word_left_extend,
  ['asleft']      = buffer.char_left_rect_extend,
  --['right']     = buffer.char_right,  -- KEYSYMS
  ['sright']      = buffer.char_right_extend,
  ['cright']      = buffer.word_right,
  ['csright']     = buffer.word_right_extend,
  ['asright']     = buffer.char_right_rect_extend,
  --['home']      = buffer.home,      -- KEYSYMS
  ['shome']       = buffer.home_extend,
  ['chome']       = buffer.document_start,
  ['cshome']      = buffer.document_start_extend,
  ['ashome']      = buffer.home_rect_extend,
  --['end']       = buffer.line_end,  -- KEYSYMS
  ['send']        = buffer.line_end_extend,
  ['cend']        = buffer.document_end,
  ['csend']       = buffer.document_end_extend,
  ['asend']       = buffer.line_end_rect_extend,
  --['pgup']      = buffer.page_up,   -- KEYSYMS
  ['spgup']       = buffer.page_up_extend,
  ['aspgup']      = buffer.page_up_rect_extend,
  --['pgdn']      = buffer.page_down, -- KEYSYMS
  ['spgdn']       = buffer.page_down_extend,
  ['aspgdn']      = buffer.page_down_rect_extend,
  ['cdel']        = buffer.del_word_right,
  ['csdel']       = buffer.del_line_right,
  --['ins']       = buffer.edit_toggle_overtype,  -- KEYSYMS
  --['\b']        = buffer.delete_back, -- KEYSYMS
  ['c\b']         = buffer.del_word_left,
  ['cs\b']        = buffer.del_line_left,
  --['\t']        = bt,                 -- KEYSYMS
  ['s\t']         = bbt,

  --[[

    Additional keys/functions may be added here as needed,
    but user specific keys should be accounted for in
    function UserkeyEvent.

  --]]
}
-- END otherKeyActions

         -----------------------------------------
         -----        macro "history"        -----
          -----         data elements         ----
         -----------------------------------------

-- the recorded macro history stack
local RKStack = {}

-- recorded key types
local USER_KEY              = 1
local MODE_KEY              = 2   -- not used
local KEYCHAIN_KEY          = 3   -- not used
local LEXER_KEY             = 4
local G_TABLE_FUNCTION_KEY  = 5
local KEYSYMS_KEY           = 6
local OTHER_KEY             = 7
local CHARACTER_KEY         = 8
local GOK_KEY               = 9

-- recorded key definitions
local RKDef = {
  [USER_KEY] = 'User defined function',
  [MODE_KEY] = 'Mode key',
  [KEYCHAIN_KEY] = 'Keychain',
  [LEXER_KEY] = 'Lexer key',
  [G_TABLE_FUNCTION_KEY] = '_G.keys function',
  [KEYSYMS_KEY] = 'KEYSYMS key',
  [OTHER_KEY] = 'textadept internal key',
  [CHARACTER_KEY] = 'character insertion key',
  [GOK_KEY] = "TARP's best guess"
}

--[[
                  =======================
                  ====  LOCAL PROCS  ====
                  =======================
--]]

-- used (obviously) for debug
local Debug = function(msgOut)
  local mode = ui.dialogs.msgbox{
    title = '**** DEBUG ****', text = msgOut,
    icon = 'gtk-dialog-info',
    button1 = 'CONTINUE'
  }
end
-- END Debug

-- Inform user that a major error has occurred
local NoGo = function(msgOut)
  local mode = ui.dialogs.msgbox{
    title = '**** ERROR ****', text = msgOut,
    icon = 'gtk-dialog-error',
    button1 = 'CONTINUE'
  }
end
-- END NoGo

-- User information message
local UserInfo = function(msgOut)
  local mode = ui.dialogs.msgbox{
    title = '**** INFORMATION ****', text = msgOut,
    icon = 'gtk-dialog-info',
    button1 = 'CONTINUE'
  }
end
-- END UserInfo

-- asks user for a YES/NO answer
-- returns true if YES
-- returns false if NO
local UserYesNo = function(msgOut)
  local button = ui.dialogs.msgbox{
    title = '**** CHOOSE YES OR NO ****',
    text = msgOut,
    informative_text = {
      'Click on "YES" or "NO" button below,'
    },
    button1 = 'YES',
    button2 = 'NO',
  }
  if button == 1 then
    return true
  else
    return false
  end
end
-- END UserYesNo

--[[
------------------------------------------------------------

  ********  ROLL YOUR OWN USER EXTENSIONS!  ********

  This function allows user modification to the macro
  recorder. The user may place their own key actions in
  this function.

  Just initiatiate action based on the appropriate values
  of

   code, shift, control, alt, meta, capsLock,
   keyModifiers, and/or keySymbol

  by performing a

    table.insert(RKeys,
        {
          keyModifiers,
          keySymbol,
          cka_function
        }
      )

  and returning "true"

  "cka_function" is a list of one or more key sequence
  functions.

  See documentation in file "TARP_DOC.txt" in this folder
  for full details.

------------------------------------------------------------
--]]
local UserkeyEvent = function ()
  --[[

    <== input:
      code, shift, control, alt, meta, capsLock,
      keyModifiers, keySymbol, keySequence

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a user defined event

  --]]
  -- essentially a giant CASE/SELECT defaulting to false
  -- if nothing meets key action criteria

  --  if KEYPRESS_CRITERIA_SATISFIED then
  --    perform table.insert
  --    return true
  --  end
  --
  --  next if test, etc.

  -- default return if nothing matches
  return false
end
-- END UserkeyEvent

--[[

                   ----------------------
                   determine key sequence
                   ----------------------

  I have shamelessly taken Mitchell's code from
  _HOME/core/keys.lua and modified it slightly to work
  here; in particular:

    keys.lua variable     variable here
    -----------------     -------------
      caps_lock             capsLock
      key                   taKey_sym
      M.KEYSYMS[code]       _G.keys.KEYSYMS[code]
      key_seq               taKey_seq

  The purpose was not to steal code but to maintain exact
  compatability with textadept. Of course, if textadept's
  core/keys.lua code changes then this code must be
  changed as well. Hopefully, this is the "least cost"
  method of maintaining cross-compatibility.

  The derivation of the key sequence is well documented in
  Mitchell's keys.lua source.

  Given the values of the KEYPRESS's code, shift, control,
  alt, meta, and caps lock, this function returns values
  for the key modifiers, symbol, and sequence. If the key
  symbol is not found, then the return values are:

    key modifiers:  ""
    key symbol:     "UNKNOWN"
    key sequence:   "UNKNOWN"

  If the key symbol is found, but there are no key
  modifiers, then the returned key sequence == key symbol
  and the returned key modifier is "".

--]]

local DeriveKey_seq = function()
  --[[

    <== input:
      code, shift, control, alt, meta, capsLock,

    ==> output:
      returns taKey_mod, taKey_sym, taKey_seq

  --]]

  local CTRL, ALT, META, SHIFT =
    'c', not CURSES and 'a' or 'm', 'm', 's'

  local taKey_mod, taKey_sym, taKey_seq

  if capsLock and (shift or control or alt or meta) and code < 256 then
    code = string[shift and 'upper' or 'lower'](string.char(code)):byte()
  end
  taKey_sym = code < 256 and (not CURSES or (code ~= 7 and code ~= 13)) and
    string.char(code) or _G.keys.KEYSYMS[code]
  if not taKey_sym then
    taKey_sym = 'UNKNOWN'
    taKey_seq = 'UNKNOWN'
    taKey_mod = ''
  else
    shift = shift and (code >= 256 or code == 9) -- printable chars are uppercased
    if OSX and alt and code < 256 then alt = false end -- composed key; ignore alt
    taKey_mod = (control and CTRL or '')..(alt and ALT or '')..
                (meta and OSX and META or '')..(shift and SHIFT or '')
    taKey_seq = taKey_mod..taKey_sym
  end

  return taKey_mod, taKey_sym, taKey_seq
end
-- END DeriveKey_seq

-- filters out "unnecessary" keypress codes
-- returns "true" if code should be recorded
local FilterkeyEvent = function(code)
  local ignoreCodes = {
    -- keypress codes to be bypassed
    ---- standard GDK key values
    0xff13,             -- Pause
    0xff14,             -- Scroll_Lock
    0xff7f,             -- Num_Lock
    0xffe1, 0xffe2,     -- Shift_L, Shift_R
    0xffe3, 0xffe4,     -- Control_L, Control_R
    0xffe5,             -- Caps_Lock
    0xffe6,             -- Shift_Lock
    0xffe7, 0xffe8,     -- Meta_L, Meta_R
    0xffe9, 0xffea,     -- Alt_L, Alt_R
    0xffeb, 0xffec,     -- Super_L, Super_R
    0xffed, 0xffee,     -- Hyper_L, Hyper_R
    0xff9d,             -- center key on keypad
    ---- other key values
    0xfe03              -- Alt_R on my system
  }
  for _, iCValue in ipairs(ignoreCodes)
  do
    if iCValue == code then
      return true
    end
  end
  return false
end
-- END FilterkeyEvent

-- process NoNo keys
-- these are key sequences that we strictly prohibit
local NoNoEvent = function()
  --[[

    <== input:
      keySequence

    ==> output:
      - false if KEYPRESS event ignored
      - otherwise error message shown and
        macro immediately aborted

  --]]

  -- prohibited key sequences
  if keySequence == 'c|' then goto FLUSH end
  if keySequence == 'cq' then goto FLUSH end
  if keySequence == 'caf' then goto FLUSH end
  if keySequence == 'ce' then goto FLUSH end

  -- O.K. to proceed
  if true then return false end

  ::FLUSH::
  -- show error
  NoGo(
        '---- YOU CANNOT RECORD KEY SEQUENCE "'
      ..keySequence
      ..'" ----\n'
      ..'------------      '
      ..'MACRO ABORTED'
      ..'      ------------'
    )
  -- force abort
  RKeys = {}    -- initialize table
  RKStack = {}  -- initialize history
  recordingMacro_Flag = false
  events.disconnect(events.KEYPRESS, KeyPressAction)
  ui.statusbar_text =
    '******** MACRO ABORTED ********'
  return true
end
-- END NoNoEvent

-- process keychain
local KeychainEvent = function()
  --[[

    <== input:
      code, shift, control, alt, meta, capsLock,
      keyModifiers, keySymbol

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a textadept defined keychain event

  --]]

  -- CURRENTLY KEYCHAINS ARE NOT PROCESSED
  -- AND THEY MAY NEVER BE
  -- SEE TARP_DOC.txt FOR WHY
  return false
end
-- END KeychainEvent

-- process lexer key
local LexerkeyEvent = function()
  --[[

    <== input:
      keySequence

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a textadept defined lexer key event

  --]]
  local v1, v2

  v1 = buffer:get_lexer(true)
  if (_G.keys[v1] ~= nil) then
    -- lexer active
    v2 = _G.keys[v1]
    if type(v2) == 'table' then
      -- table available
      if
        type(v2[keySequence]) == 'function' then
        table.insert(RKeys,
            {
              keyModifiers,
              keySymbol,
              v2[keySequence]
            }
          )
        return true
      end
    end
  end
  return false
end
-- END LexerkeyEvent

-- process _G.keys function
local GkeyEvent = function()
  --[[

    <== input:
      keySequence

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a textadept defined _G.keys function

  --]]
  ---- handle exceptions first
  -- tab key - caught later by KeysymsEvent
  if keySequence=='\t' then return false end
  -- shift tab - caught later by OtherKeyEvent
  if keySequence=='s\t' then return false end

  -- now test for _G.keys function
  if type(_G.keys[keySequence])=='function' then
    table.insert(RKeys,
                  {
                    keyModifiers,
                    keySymbol,
                    _G.keys[keySequence]
                  }
                )
    return true
  else
    return false
  end
end
-- END GkeyEvent

-- process KEYSYMS key
local KeysymsEvent = function()
  --[[

    <== input:
      keyModifiers, keySymbol
      NOTE: Probably only need keySequence
            but I'm paranoid

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a textadept defined KEYSYMS key seq

  --]]
  if  keyModifiers==''
        and
      keysymsActions[keySymbol]~=nil
    then
      table.insert(RKeys,
        {
          keyModifiers,
          keySymbol,
          keysymsActions[keySymbol]
        }
      )
    return true
  else
    return false
  end
end
-- END KeysymsEvent

-- process documented but unassigned keys
-- i.e.: _HOME/modules/textadept/keys.lua
local OtherKeyEvent = function()
  --[[

    <== input:
      keyModifiers, keySymbol, keySequence

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a textadept documented but unassigned
        key sequence

    NOTE: This key assignment is made after all others
    except for insertable character keys have been
    exhausted. It should be used for those keys that
    textadept uses, but doesn't assign. Likely these are
    just those underlying Scintilla macros (and other
    detritus) that don't allow convenient assignment.

  --]]
  if otherKeyActions[keySequence]~=nil then
    table.insert(RKeys,
                  {
                    keyModifiers,
                    keySymbol,
                    otherKeyActions[keySequence]
                  }
                )
    return true
  else
    return false
  end
end
-- END OtherKeyEvent

-- process printable character key
local CharkeyEvent = function()
  --[[

    <== input:

      code, keyModifiers, keySymbol

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is an insertable character

  --]]
  if  ((code > 31) and (code < 127))
        and
      keyModifiers==''  -- just a touch of paranoia here;-)
  then
    -- handles bracket autopairing
    if apbr(code) then
      table.insert(RKeys,
          {
            keyModifiers,
            keySymbol,
            {apbr, code, 1}
          }
        )
      return true
    end
    -- no autopair, so insert char
    table.insert(RKeys,
        {
          keyModifiers,
          keySymbol,
          -- buffer.add_text won't work
          {bat, keySymbol}
        }
      )
    return true
  else
    -- not a printable char
    return false
  end
end
-- END CharkeyEvent

-- process GOK keys
local GOKkeyEvent = function()
  --[[

    <== input:

      code, keyModifiers, keySymbol

    ==> output:
      - false if KEYPRESS event ignored
      - true and insertion in RKeys if KEYPRESS
        event is a GOK key

  --]]
  -- GDK_KEY_KP_Insert?
  -- or what should have been 'kpins' in KEYSYMS
  if
    (
      (keySymbol=='kpins')
        or
      (code == 0xff9e)
    )
  then
    table.insert(RKeys,
                  {
                    '',
                    'kpins',
                    buffer.edit_toggle_overtype
                  }
                )
    return true
  end
  -- GDK_KEY_KP_Delete?
  -- or what should have been 'kpdel' in KEYSYMS
  if
    (
      (keySymbol=='kpdel')
        or
      (code == 0xff9f)
    )
  then
    table.insert(RKeys,
                  {
                    '',
                    'kpdel',
                    -- strangely, there is no
                    -- "buffer.delete_forward"
                    -- i.e.: 'del' action
                    buffer.char_right,
                    buffer.delete_back
                  }
                )
    return true
  end

  -- fall through
  return false
end
-- END GOKkeyEvent

-- process unknown key event
local UnknownKeyEvent = function()
  --[[

    <== input:
      code, keyModifiers, keySymbol (for display)

    ==> output:
      - user dialog notification of error
      - false if user wishes to continue recording
      - true if user wishes to cancel recording

  --]]
  local button = ui.dialogs.msgbox{
    title = '**** CANNOT RECORD THIS KEY ****',
    text =
        '---- KEY UNASSIGNED OR UNKNOWN ----'
      ..'\n\n Key code: '
      ..code
      ..'\n Key modifiers: '
      ..((keyModifiers=='' and 'NONE') or keyModifiers)
      ..'\n Key symbol: '
      ..keySymbol,
    informative_text = {
      '"CANCEL" to cancel recording\n'
      ..'"CONTINUE" to continue ignoring key'
    },
    button1 = 'CANCEL',
    button2 = 'CONTINUE'
  }
  if button == 1 then
    return true
  else
    return false
  end
end
-- END UnknownKeyEvent

-- macro execution error handler
local XQT_RKeys_Error = function(errorMsg)
  --[[

    <== input:
      error message

    ==> output:
      inform user of execution error

  --]]
  UserInfo('---- ERROR EXECUTING MACRO ----\n'
    ..'---- ERROR: \n    '..errorMsg
  )
end
-- END XQT_RKeys_Error

-- execute RKeys
local XQT_RKeys = function()
  --[[

    <== input:
      RKeys

    ==> output:
      - currently recorded macro is executed
      - (sounds harsh does't it;-)

  --]]
  local iHigh = #RKeys
  local iStart = 3
  for keyNum = 1, iHigh do
    for keyFun = iStart, #RKeys[keyNum] do
      if (type(RKeys[keyNum][keyFun]) == 'function' ) then
        RKeys[keyNum][keyFun]()
      else
        -- first try explicit parm passing
        -- up to a point of reasonableness
        -- hopefully, this is the fastest way
        local numParms = #RKeys[keyNum][keyFun] - 1
        if numParms == 1 then
            RKeys[keyNum][keyFun][1](
            RKeys[keyNum][keyFun][2]
          )
        elseif numParms == 2 then
            RKeys[keyNum][keyFun][1](
            RKeys[keyNum][keyFun][2],
            RKeys[keyNum][keyFun][3]
          )
        elseif numParms == 3 then
            RKeys[keyNum][keyFun][1](
            RKeys[keyNum][keyFun][2],
            RKeys[keyNum][keyFun][3],
            RKeys[keyNum][keyFun][4]
          )
        elseif numParms == 4 then
            RKeys[keyNum][keyFun][1](
            RKeys[keyNum][keyFun][2],
            RKeys[keyNum][keyFun][3],
            RKeys[keyNum][keyFun][4],
            RKeys[keyNum][keyFun][5]
          )
        elseif numParms == 5 then
            RKeys[keyNum][keyFun][1](
            RKeys[keyNum][keyFun][2],
            RKeys[keyNum][keyFun][3],
            RKeys[keyNum][keyFun][4],
            RKeys[keyNum][keyFun][5],
            RKeys[keyNum][keyFun][6]
          )
        else
          -- NOTE: table.unpack of RKeys[keyNum][keyFun]
          --  did not work when this was coded, so we will
          --  transfer this complex structure to a simple
          --  one which does work
          local simpleArray = {}
          for i = 1, numParms do
            table.insert(simpleArray,RKeys[keyNum][keyFun][i+1] )
          end
          RKeys[keyNum][keyFun][1](
              table.unpack(simpleArray)
            )
        end
      end
    end
  end
end
-- END XQT_RKeys

-- action taken on keypress when recording
KeyPressAction = function(
    taCode, taShift, taControl, taAlt, taMeta, taCapsLock
  )

  -- set upvalues
  code      = taCode
  shift     = taShift
  control   = taControl
  alt       = taAlt
  meta      = taMeta
  capsLock  = taCapsLock

  -- check to see if we bypass the KEYPRESS
  if FilterkeyEvent(code) then return end

  -- get the textadept keypress litterals
  keyModifiers, keySymbol, keySequence = DeriveKey_seq()
  if NoNoEvent() then return end


             ---------------------------------
             -- analyze/record the KEYPRESS --
             ---------------------------------

  -- user option?
  if UserkeyEvent() then
    table.insert(RKStack, RKDef[USER_KEY])
    goto SHOW_ACTION
  end
  -- _G.keys keychain?
  -- NOT CURRENTLY (MAYBE NEVER) PROCESSED
  --if KeychainEvent() then
  --  table.insert(RKStack, RKDef[KEYCHAIN_KEY])
  --  goto SHOW_ACTION
  --  return
  --end
  -- lexer function?
  if LexerkeyEvent() then
    table.insert(RKStack, RKDef[LEXER_KEY])
    goto SHOW_ACTION
    return
  end
  -- _G.keys defined function?
  if GkeyEvent() then
    table.insert(RKStack, RKDef[G_TABLE_FUNCTION_KEY])
    goto SHOW_ACTION
    return
  end
  -- KEYSYMS function?
  if KeysymsEvent() then
    table.insert(RKStack, RKDef[KEYSYMS_KEY])
    goto SHOW_ACTION
    return
  end
  -- documented but unassigned key?
  -- i.e.: _HOME/modules/textadept/keys.lua
  if OtherKeyEvent() then
    table.insert(RKStack, RKDef[OTHER_KEY])
    goto SHOW_ACTION
    return
  end
  -- character insertion?
  if CharkeyEvent() then
    table.insert(RKStack, RKDef[CHARACTER_KEY])
    goto SHOW_ACTION
    return
  end
  -- GOK key?
  if GOKkeyEvent() then
    table.insert(RKStack, RKDef[GOK_KEY])
    goto SHOW_ACTION
    return
  end
  --  TILT!
  -- unknown key - abort/continue
  if UnknownKeyEvent() then
    -- abort macro
    RKeys = {}    -- initialize table
    RKStack = {}  -- initialize history
    recordingMacro_Flag = false
    events.disconnect(events.KEYPRESS, KeyPressAction)
    ui.statusbar_text =
      '******** MACRO ABORTED ********'
    return
  else
    -- continue recording
    ui.statusbar_text =
      '******** CONTINUING TO RECORD - KEY IGNORED ********'
    return
  end

::SHOW_ACTION::
  ui.statusbar_text =
    '-RECORDING-    '
    ..'#: '..#RKeys
    ..',    KeySeq:    '..keySequence
    ..',    Action:    '..RKStack[#RKStack]

end
-- END KeyPressAction

       ---------------------------------------------
       ----    PROCS USED BY SAVE/LOAD MACRO    ----
       ---------------------------------------------

-- takes a key modifier and sequence string
-- and converts it to a tam string
-- returning the tam string
local ms2tam = function(km, ks)
  local tamAry = {}
  tamAry[1] = km
  tamAry[2] = '-'
  for i1 = 1, string.len(ks) do
    if i1 ~= 1 then
      tamAry[#tamAry+1] = '|'
    end
    tamAry[#tamAry+1] =
      string.byte(ks, i1)
  end
  return table.concat(tamAry)
end
-- END ms2tam

-- takes a tam line (minus '\n')
-- and converts it to a key modifier
-- and sequence string returning them
-- returns nil if line starts with "#"
local tam2ms = function(tam)
  local sLen, sStart, km, ks, nStart, wIndex
  if string.sub(tam,1,1) == '#' then return nil end
  sLen = string.len(tam)
  -- get modifier
  for i1 = 1, sLen do
    if string.sub(tam,i1,i1) == '-' then
      sStart = i1+1
      if i1 == 1 then
        km = ''
      else
        km = string.sub(tam, 1, i1-1)
      end
      break
    end
  end
  -- now get sequence
  ks = ''
  wIndex = sStart
  nStart = sStart
  while wIndex <= sLen do
    if  string.sub(tam,wIndex,wIndex) == '|' then
      ks = ks .. string.char(
          tonumber(string.sub(tam,nStart,wIndex-1))
        )
      nStart = wIndex + 1
    end
    wIndex = wIndex + 1
  end
  -- must be a value left
  ks = ks .. string.char(
      tonumber(string.sub(tam,nStart,wIndex-1))
    )

  return km, ks
end
-- END tam2ms

-- check for directory existence
-- from internet stackoverflow
local function isDir(name)
if type(name) ~= "string" then return false end
local cd = lfs.currentdir()
local is = lfs.chdir(name) and true or false
lfs.chdir(cd)
return is
end
-- END isDir

-- check for file existence
-- from internet stackoverflow
local function isFile(name)
if type(name)~="string" then return false end
if not isDir(name) then
  return os.rename(name,name) and true or false
  -- note that the short evaluation is to
  -- return false instead of a possible nil
end
return false
end
-- END isFile

-- checks for valid macrosHome directory
-- returns true if found or created
-- returns false if non-existant
local MacrosDirOK = function(mDir)
  --[[

    <== input:
      full path to macros directory

    ==> output:
      - true if found or created
      - false if non-existant

  --]]
  local mkdir_Flag, newDir_Flag, newDirMsg
  if isDir(mDir) then return true end
  --try to create
  mkdir_Flag = UserYesNo(
        '"macros" directory not found.\n'
      ..'It must be created to save/load macros.\n'
      ..'Make "macros" directory now?'
    )
  if not mkdir_Flag then
    -- user chooses not to create
    return false
  else
    -- create directory if possible
    newDir_Flag, newDirMsg = lfs.mkdir(macrosHome)
    if newDir_Flag then
      return true
    else
      UserInfo('-- Error creating macros directory\n'
          ..'---- Error: '..newDirMsg
        )
      return false
    end
  end
end
--END MacrosDirOK


--[[
                  =======================
                  ====    MODULES    ====
                  ==    (finally;-)    ==
                  =======================
--]]

-- (re)play macro
-- typically assign to a "top level" (e.g. "f11") key
-- to facilitate repetative macro actions
function M.ReplayMacro()
  local XQT_CKA_Status, XQT_CKA_ErrorMsg
  local next = next
  if next(RKeys) == nil then
    -- nothing recorded
    ui.statusbar_text =
      '******** NOTHING HAS BEEN RECORDED ********'
    return
  end

  -- items in RKeys
  if recordingMacro_Flag then
    -- trying to replay while recording
    -- since this _G.keys assignment has been
    -- added at this point, we must remove it
    table.remove(RKeys) -- take out replay
    ui.statusbar_text =
      '******** CANNOT REPLAY WHILE RECORDING ********'
  else
    -- (re)play recorded macro
    ui.statusbar_text =
      '******** RUNNING MACRO ********'
    buffer:begin_undo_action()
    XQT_CKA_Status, XQT_CKA_ErrorMsg = xpcall(
        XQT_RKeys,
        XQT_RKeys_Error
      )
    if not XQT_CKA_Status then
      XQT_RKeys_Error(XQT_CKA_ErrorMsg)
    end
    buffer:end_undo_action()
    ui.statusbar_text =
      '******** MACRO FINISHED ********'
  end
end
-- END M.ReplayMacro

-- toggle macro record state
function M.ToggleMacro()
  if recordingMacro_Flag then
    -- recording complete, close shop
    recordingMacro_Flag = false
    events.disconnect(events.KEYPRESS, KeyPressAction)
    table.remove(RKeys) -- take out toggle
    if #RKeys > 0 then
      ui.statusbar_text =
        '******** MACRO RECORDED - '
        ..#RKeys
        ..' ITEMS ********'
    else
    ui.statusbar_text =
      '******** NOTHING WAS RECORDED ********'
    end
  else
    -- start recording
    recordingMacro_Flag = true
    RKeys = {}    -- initialize table
    RKStack = {}  -- initialize history
    events.connect(events.KEYPRESS, KeyPressAction, 1)
    ui.statusbar_text =
      '******** READY TO RECORD MACRO ********'
  end
end
-- END M.ToggleMacro

-- save macro in macro directory
function M.SaveMacro()
  local newMacro_Flag
  local macFile -- file name component
  local macFFN  -- filename + extension
  local macDesc1, macDesc2, macDesc3, macDesc4
  local fHandle, newMacro_Flag

  -- anything to save?
  local next = next
  if next(RKeys) == nil then
    -- nothing recorded
    ui.statusbar_text =
      '******** NOTHING HAS BEEN RECORDED ********'
    return
  end

  -- must have available directory
  if not MacrosDirOK(macrosHome) then return end

  -- see if new file or replacement
  newMacro_Flag = UserYesNo('Is this a new macro?')
  if newMacro_Flag then
    -- new macro: get filename and comments
    local button, inputs
    button, inputs = ui.dialogs.inputbox{
    title = 'ENTER FILE NAME AND COMMENTS',
    informative_text = {
    '-- Macro name and description --', -- main message text
    'File Name (no extension):',
    'Description (line 1):',
    'Description (line 2):',
    'Description (line 3):',
    'Description (line 4):',
    },
    button1 = 'OK',
    button2 = 'CANCEL'
    }
    macFile =  inputs[1]
    macDesc1 = inputs[2] ;  macDesc2 = inputs[3]
    macDesc3 = inputs[4] ;  macDesc4 = inputs[5]
    if button == 2 then return end
    -- check for extant file & verify overwrite
    macFFN =
        macrosHome
      ..( (WIN32 and '\\') or '/')
      ..macFile
      ..'.tam'
    if isFile(macFFN) then
      if not UserYesNo(
                'File: '..macFile
              ..' already exists.\n'
              ..'**** OVERWRITE? ****'
              )
         then
        return
      end
    end
  else
    -- replacement: get file to replace
    local filename = ui.dialogs.fileselect{
            title = '****  REPLACE MACRO FILE  ****',
            with_directory = macrosHome,
            with_extension = {'tam'},
            select_multiple = false
          }
    if filename then
      macFFN = filename -- returns full path
    else
      return
    end
  end

  -- now write macro (with comments if new)
  fHandle = io.open(macFFN, 'wb')
  if newMacro_Flag then
    -- write comments, if any
    if macDesc1 ~= '' then
      fHandle:write('# ', macDesc1, '\n')
    end
    if macDesc2 ~= '' then
      fHandle:write('# ', macDesc2, '\n')
    end
    if macDesc3 ~= '' then
      fHandle:write('# ', macDesc3, '\n')
    end
    if macDesc4 ~= '' then
      fHandle:write('# ', macDesc4, '\n')
    end
  end
  -- write key sequences
  for i, v in ipairs(RKeys) do
    tamStr = ms2tam(v[1], v[2])
    fHandle:write(tamStr, '\n')
  end
  fHandle:close()
  ui.statusbar_text =
    '********      MACRO SAVED      ********'
end
-- END M.SaveMacro

-- load & compile macro from macro directory
function M.LoadMacro()
  local macFFN  -- filename + extension
  local fHandle, newMacro_Flag
  local tamIn

  -- must have available directory
  if not MacrosDirOK(macrosHome) then return end

  -- get file to load
  local filename = ui.dialogs.fileselect{
    title = '****  LOAD & COMPILE MACRO FILE  ****',
    with_directory = macrosHome,
    with_extension = {'tam'},
    select_multiple = false
    }
  if filename then
    macFFN = filename -- returns full path
  else
    ui.statusbar_text =
      '******** LOAD/COMPILE ABORTED ********'
    return
  end

  -- load & compile
  RKeys = {}    -- initialize table
  RKStack = {}  -- initialize history
  fHandle = io.open(macFFN, 'rb')
  tamIn = fHandle:read('l')
  while tamIn do
    -- bypass comments
    if string.sub(tamIn, 1, 1) ~= '#' then
      -- get "key" information
      -- (pun intended;-)
      keyModifiers, keySymbol = tam2ms(tamIn)
      keySequence = keyModifiers..keySymbol
      if
        (
          (keyModifiers == '')
            and
          (string.len(keySymbol) > 1)
        )
      then
        code = 0
      else
        -- only needed for CharkeyEvent
        code = string.byte(keySymbol, 1)
      end
      ----------------------------------
      -- analyze/compile the KEYPRESS --
      ----------------------------------
      -- user option?
      if UserkeyEvent() then
        table.insert(RKStack, RKDef[USER_KEY])
        goto NEXT_LINE
      end
      -- _G.keys keychain?
      -- NOT CURRENTLY (MAYBE NEVER) PROCESSED
      --if KeychainEvent() then
      --  table.insert(RKStack, RKDef[KEYCHAIN_KEY])
      --  goto NEXT_LINE
      --  return
      --end
      -- lexer function?
      if LexerkeyEvent() then
        table.insert(RKStack, RKDef[LEXER_KEY])
        goto NEXT_LINE
        return
      end
      -- _G.keys defined function?
      if GkeyEvent() then
        table.insert(RKStack, RKDef[G_TABLE_FUNCTION_KEY])
        goto NEXT_LINE
        return
      end
      -- KEYSYMS function?
      if KeysymsEvent() then
        table.insert(RKStack, RKDef[KEYSYMS_KEY])
        goto NEXT_LINE
        return
      end
      -- documented but unassigned key?
      -- i.e.: _HOME/modules/textadept/keys.lua
      if OtherKeyEvent() then
        table.insert(RKStack, RKDef[OTHER_KEY])
        goto NEXT_LINE
        return
      end
      -- character insertion?
      if CharkeyEvent() then
        table.insert(RKStack, RKDef[CHARACTER_KEY])
        goto NEXT_LINE
        return
      end
      -- GOK key?
      if GOKkeyEvent() then
        table.insert(RKStack, RKDef[GOK_KEY])
        goto NEXT_LINE
        return
      end
      --  TILT!
      -- unknown key - abort/continue
      if UnknownKeyEvent() then
        -- abort read
        RKeys = {}    -- initialize table
        RKStack = {}  -- initialize history
        fHandle:close()
        ui.statusbar_text =
          '******** LOAD/COMPILE ABORTED ********'
        return
      else
        -- continue reading
        ui.statusbar_text =
          '******** CONTINUING TO LOAD - KEY IGNORED ********'
      end
    end
    ::NEXT_LINE::
    tamIn = fHandle:read('l')
  end
  fHandle:close()
  ui.statusbar_text =
    '********      MACRO LOADED      ********'
  end
-- END M.LoadMacro

-- show RKeys
function M.ShowMacro()
  if #RKeys > 0 then
    local button, message
    for i, v in ipairs(RKeys) do
      message =
        '--   key #:    '
          ..i
          ..'\n--   key_sequence: '
          ..v[1]
          ..v[2]
          ..'\n--   key_type: '
          ..RKStack[i]
      button = ui.dialogs.msgbox{
        title = '-- '..#RKeys.. ' MACRO ITEMS --',
        text = message,
        informative_text = {
            '"CANCEL"       to stop review\n'
          ..'"CONTINUE"  to continue review'
        },
        button1 = 'CONTINUE',
        button2 = 'CANCEL'
      }
      if button == 2 then
        return
      end
    end
  else
    UserInfo('**** NOTHING CURRENTLY RECORDED ****')
  end
end
-- END M.ShowMacro


return M
