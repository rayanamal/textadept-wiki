local textadept = _m.textadept
local editing = textadept.editing
local execute = textadept.run.execute

-- Commands for the pkgbuild module.
module('_m.pkgbuild.commands', package.seeall)

local function execute_extern(command)
  local filepath = buffer.filename:iconv(_CHARSET, 'UTF-8')
  local filedir, filename = filepath:match('^(.+[/\\])([^/\\]+)$')

  if not term_cmd then
    term_cmd = 'xterm -hold -e '
  end

  if not exec_cmd then
    function exec_cmd(cmd)
      os.execute(term_cmd..cmd..' &')
    end
  end

  local current_dir = lfs.currentdir()
  lfs.chdir(filedir)
  exec_cmd(command)
  lfs.chdir(current_dir)
end

if use_term then
  execute = execute_extern
end

local function prepare()
  execute('makepkg -g')
end

local function build()
  execute('makepkg -f')
end

local function install()
  execute('makepkg -i')
end

local function source()
  execute('makepkg --source -f')
end

local function clean()
  execute('rm -r {src,pkg,*pkg.tar.{gz,xz}}')
end

-- PKGBUILD-specific key commands.
local keys = textadept.keys
if type(keys) == 'table' then
  keys.pkgbuild = {
    al = {
      m = { io.open_file, (_HOME..'/modules/pkgbuild/init.lua'):iconv('UTF-8', _CHARSET) },
      p = { prepare },
      b = { build } ,
      i = { install },
      s = { source },
      r = { clean }
    },
    cq = { editing.block_comment, '#' },
  }
end
