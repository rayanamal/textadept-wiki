-- Snippets for the pkgbuild module.
module('_m.pkgbuild.snippets', package.seeall)

local snippets = _G.snippets

if type(snippets) == 'table' then
  snippets.pkgbuild = {
    --packager info
    maintain = "# Maintainer: %1(your_name) <%2(name)@%3(host).%4(com)>",
    contrib  = "# Contributor: %1(your_name) <%2(name)@%3(host).%4(com)>",

    --default variables
    name	= "pkgname=%1(name)",
    ver	  = "pkgver=%1(version)",
    rel	  = "pkgrel=%1(release)",
    desc	= "pkgdesc=\"%1(descrition)\"",
    arch	= "arch=(%1(\'i686\') %2(\'x86_64\'))",
    url	  = "url=\"%1(url)\"",
    lice	= "license=(\'%1(license)\'%0)",
    deps	= "depends=(\'%1(dependency)\'%0)",
    optdep= "optdepends=(\'%1(optional_dependency)%2(: %3(descrition))\'%0)",
    mdeps	= "makedepends=(\'%1(make_dependency)\'%0)",
    prov	= "provides=(\'%1(provides)\'%0)",
    confl	= "conflicts=(\'%1(conflicts)\'%0)",
    rep	  = "replaces=(\'%1(replaces)\'%0)",
    inst	= "install=%1(install_file).install%0",
    option= "options=(\'%1(option)\'%0)",
    src	  = "source=(%1(url)%0)",
    md5	  = "md5sums=(\'%1(md5sum)\'%0)",

    --build commands
    build	= "build() {\n  cd \"$srcdir/%1($pkgname)%2(-%3($pkgver))\"\n\n  %0\n}",
    pkgd	= "${pkgdir}",
    srcd	= "${srcdir}",
    install	= "install -Dm%1(644) %2($srcdir)/ %3($pkgdir)/",
    patch	= "patch -Np%1(1) -i ${srcdir}/%2(patch_file).patch || return 1",
    sed	  = "sed -i 's/%1(string)/%2(string)/' %3(target_file)",

    --special packages
    cvspkg    = "_cvsroot=%1(cvs_url)\n_cvsmod=%2(mod_name)\n\nbuild() {\n  cd \"$srcdir\"\n  msg \"Connecting to $_cvsmod.sourceforge.net CVS server....\"\n  if [ -d $_cvsmod/CVS ]; then\n    cd $_cvsmod\n    cvs -z3 update -d\n  else\n    cvs -z3 -d $_cvsroot co -D $pkgver -f $_cvsmod\n    cd $_cvsmod\n  fi\n\n  msg \"CVS checkout done or server timeout\"\n  msg \"Starting build...\"\n\n  rm -rf \"$srcdir/$_cvsmod-build\"\n  cp -r \"$srcdir/$_cvsmod\" \"$srcdir/$_cvsmod-build\"\n  cd \"$srcdir/$_cvsmod-build\"\n\n  %0\n  \n}",
    svnpkg	  = "_svntrunk=%1(svn_url)\n_svnmod=%2(mod_name)\n\nbuild() {\n  cd \"$srcdir\"\n\n  if [ -d $_svnmod/.svn ]; then\n    (cd $_svnmod && svn up -r $pkgver)\n  else\n    svn co $_svntrunk --config-dir ./ -r $pkgver $_svnmod\n  fi\n\n  msg \"SVN checkout done or server timeout\"\n  msg \"Starting make...\"\n\n  rm -rf \"$srcdir/$_svnmod-build\"\n  cp -r \"$srcdir/$_svnmod\" \"$srcdir/$_svnmod-build\"\n  cd \"$srcdir/$_svnmod-build\"\n\n  %0\n  \n}",
    gitpkg	  = "_gitroot=%1(git_url)\n_gitname=%2(git_name)\n\nbuild() {\n  cd \"$srcdir\"\n\n  msg \"Connecting to GIT server....\"\n\n  if [ -d $_gitname ] ; then\n    cd $_gitname && git pull origin\n    msg \"The local files are updated.\"\n  else\n    git clone $_gitroot\n  fi\n\n  msg \"GIT checkout done or server timeout\"\n  msg \"Starting build...\"\n\n  rm -rf \"$srcdir/$_gitname-build\"\n  git clone \"$srcdir/$_gitname\" \"$srcdir/$_gitname-build\"\n  cd \"$srcdir/$_gitname-build\"\n\n  %0\n  \n}",
    hgpkg     = "_hgroot=%1(hg_url)\n_hgrepo=%2(repo_name)\n\nbuild() {\n  cd \"$srcdir\"\n\n  if [ -d ${_hgrepo} ]; then\n    cd ${_hgrepo}\n    hg pull -u || return 1\n  else\n    hg clone ${_hgroot} ${_hgrepo} || return 1\n  fi\n\n  msg \"Mercurial checkout done or server timeout\"\n  msg \"Starting build...\"\n\n  rm -rf \"$srcdir/${_hgrepo}-build\"\n  cp -r \"$srcdir/${_hgrepo}\"\"$srcdir/${_hgrepo}-build\"\n  cd \"$srcdir/${_hgrepo}-build\"\n\n  %0\n  \n}",
    darcspkg  = "_darcstrunk=%1(darcs_url)\n_darcsmod=%2(mod_name)\n\nbuild() {\n  cd \"$srcdir\"\n\n  msg \"Checking for previous build\"\n\n  if [ -d $srcdir/$_darcsmod/_darcs] ; then\n    msg \"Retrieving missing patches\"\n    cd $_darcsmod\n    darcs pull -a $_darcstrunk/$_darcsmod\n  else\n    msg \"Retrieving complete sources\"\n    darcs get --lazy $_darcstrunk/$_darcsmod\n  fi\n\n  msg \"Starting build...\"\n\n  rm -rf \"$srcdir/$_darcsmod-build\"\n  cp -r \"$srcdir/$_darcsmod\" \"$srcdir/$_darcsmod-build\"\n\n  %0\n  \n}",
    makegnome	= "make  GCONF_DISABLE_MAKEFILE_SCHEMA_INSTALL=1 DESTDIR=\"$pkgdir\" install || return 1\n\ninstall -m755 -d \"$pkgdir\"/usr/share/gconf/schemas\ngconf-merge-schema \"$pkgdir\"/usr/share/gconf/schemas/${pkgname}.schemas \\\n            \"$pkgdir\"/etc/gconf/schemas/*.schemas || return 1\nrm -f \"$pkgdir\"/etc/gconf/schemas/*.schemas%0",
    carch     = "if [ \"${CARCH}\" = %1(\'x86_64\') ]; then\n  %2(args)\n%3(elif [ \"${CARCH}\" = %4(\'i686\') ]; then\n  %5(args))\nfi\n  %0",

    --install files
    preinst  = "pre_install() {\n  %1(command)\n}\n\n",
    postinst = "post_install() {\n  %1(command)\n}\n\n",
    preup    = "pre_upgrade() {\n  %1(command)\n}\n\n",
    postup   = "post_upgrade() {\n  %1(command)\n}\n\n",
    prerm    = "pre_remove() {\n  %1(command)\n}\n\n",
    postrm   = "post_remove() {\n  %1(command)\n}\n\n",

    --special install files
    installgnome  = "pkgname=%1(name)\n\npost_install() {\n  /usr/sbin/gconfpkg --install ${pkgname}\n  update-desktop-database -q\n}\n\npre_upgrade() {\n  pre_remove $1\n}\n\npost_upgrade() {\npost_install $1\n}\n\npre_remove() {\n  /usr/sbin/gconfpkg --uninstall ${pkgname}\n}\n\npost_remove() {\n  update-desktop-database -q\n}\n",
  }
end
