-- The pkgbuild module.
-- Provides utilities for editing PKGBUILD code.
module('_m.pkgbuild', package.seeall)

if type(_G.snippets) == 'table' then
---
-- Container for PKGBUILD-specific snippets.
-- @class table
-- @name snippets.pkgbuild
  _G.snippets.pkgbuild = {}
end

if type(_G.keys) == 'table' then
---
-- Container for PKGBUILD-specific key commands.
-- @class table
-- @name keys.pkgbuild
  _G.keys.pkgbuild = {}
end

require 'pkgbuild.commands'
require 'pkgbuild.snippets'

function set_buffer_properties()

end
